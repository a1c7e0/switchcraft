# Switchcraft device test package

Download and extract [switchcraft-test-suite-2026-11-09-r3.zip](https://github.com/a1c7e0/switchcraft/releases/download/test-suite-2026-11-09-r3/switchcraft-test-suite-2026-11-09-r3.zip) directly into the SD root, merging files and preserving existing saves and configuration. Use application-mode hbmenu. Start with START_HERE.md and report results as PASS, FAIL or NOT TESTED.

For licensing and reproducibility, the matching optional source archive is [switchcraft-source-2026-11-09-r3.tar.gz](https://github.com/a1c7e0/switchcraft/releases/download/test-suite-2026-11-09-r3/switchcraft-source-2026-11-09-r3.tar.gz). Hardware execution is not established by this package.
