# Switchcraft R3 device test package

Extract this ZIP directly into the SD root: [download the package](https://github.com/a1c7e0/switchcraft/releases/download/test-suite-2026-11-09-r3/switchcraft-test-suite-2026-11-09-r3.zip). Merge folders and preserve existing saves/configuration. Use Switch 1, Atmosphere, and application-mode hbmenu. The required applications are under switch/.

## Focused R3 retest

Before starting, record Switch firmware, Atmosphere and hbmenu versions. For every Java 25 attempt, launch a fresh application-mode hbmenu process and start only one test. Let its result screen finish, close the app normally with +, then close and reopen hbmenu before the next attempt. Record the approximate wait time and result.

| Order | App and action | Continue when |
| --- | --- | --- |
| 1 | `zero-services-test`, L | Record the new guard and committed-range checks, raw statuses/results, and canary outcome. Do this first. |
| 2 | Fresh `java25-test`, A | Continue only if the result shows `Hello from Horizon Java 25`. |
| 3 | Fresh `java25-test`, X | Run only after A passes; record the JNI/FFM suite result. |
| 4 | Fresh `java25-test`, Y | Run only after X passes; record the startup-agent result. |
| 5 | Fresh `switchcraft-java25`, A | Run after standalone A/X/Y pass; record the combined Hello result. |
| 6 | Fresh `switchcraft-java25`, X | Run only after combined A passes; record the SDL JNI/FFM result. |

If a prerequisite fails, leave dependent actions untested. After the attempts, export all logs and unique tick-named VM captures. `java25-test.log` may append across runs, so preserve each attempt's stdout/stderr capture. The collector below exports its allowlisted logs, including `hs_err_pid*.log` in the two Java 25 app folders. Review and attach Atmosphere/system crash reports separately if present. Cross-builds and host results are not device passes.

For licensing and reproducibility, download the matching optional source archive [switchcraft-source-2026-11-09-r3.tar.gz](https://github.com/a1c7e0/switchcraft/releases/download/test-suite-2026-11-09-r3/switchcraft-source-2026-11-09-r3.tar.gz). To export allowed diagnostic logs, run `python3 switch/mc-runtime/tools/collect-feedback.py --sd-root /path/to/SD --output ./switchcraft-feedback.zip` on a PC; choose an output path outside the SD card.
