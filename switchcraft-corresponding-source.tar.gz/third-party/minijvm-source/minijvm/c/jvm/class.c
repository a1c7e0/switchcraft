/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "jvm.h"
#include "jvm_util.h"
#include "garbage.h"

//===============================    Create and load  ==================================


JClass *class_create(Runtime *runtime) {
    s32 jcsize = sizeof(JClass);
    JClass *clazz = jvm_calloc(jcsize);
    if (!clazz) return NULL;
    clazz->mb.heap_size = jcsize;
    clazz->mb.clazz = clazz;
    clazz->mb.type = MEM_TYPE_CLASS;
    clazz->field_instance_len = 0;
    clazz->field_static = NULL;
    clazz->status = CLASS_STATUS_RAW;
    clazz->_load_class_from_bytes = _LOAD_CLASS_FROM_BYTES;
    //
    jthreadlock_create(runtime, &clazz->mb);
    constant_list_create(clazz);
    clazz->arr_class_type = pairlist_create(16);
    clazz->insFieldPtrIndex = arraylist_create(8);
    clazz->staticFieldPtrIndex = arraylist_create(4);
    clazz->supers = arraylist_create(4);
    if (!clazz->constantPool.utf8CP || !clazz->constantPool.classRef ||
        !clazz->constantPool.stringRef || !clazz->constantPool.fieldRef ||
        !clazz->constantPool.methodRef || !clazz->constantPool.interfaceMethodRef ||
        !clazz->arr_class_type || !clazz->insFieldPtrIndex ||
        !clazz->staticFieldPtrIndex || !clazz->supers) {
        jvm_fatal_oom("class-core-metadata", sizeof(JClass));
    }
    gc_obj_reg(runtime, clazz);
    return clazz;
}

s32 class_destroy(JClass *clazz) {
    //jvm_printf("class_destroy   : %s\n", utf8_cstr(clazz->name));
    _DESTROY_CLASS(clazz);
    pairlist_destroy(clazz->arr_class_type);
    arraylist_destroy(clazz->insFieldPtrIndex);
    arraylist_destroy(clazz->staticFieldPtrIndex);
    arraylist_destroy(clazz->supers);
    if (clazz->iface_layout) {
        jvm_free(clazz->iface_layout->slots);
        jvm_free(clazz->iface_layout);
    }
    if (clazz->vtable) jvm_free(clazz->vtable);
    if (clazz->itable) {
        if (clazz->itable->interfaces) jvm_free(clazz->itable->interfaces);
        if (clazz->itable->entries) {
            s32 i;
            for (i = 0; i < clazz->itable_length; i++) {
                if (clazz->itable->entries[i].methods) jvm_free(clazz->itable->entries[i].methods);
                jvm_free(clazz->itable->entries[i].status);
            }
            jvm_free(clazz->itable->entries);
        }
        jvm_free(clazz->itable);
    }
    jvm_free(clazz);
    return 0;
}

void constant_list_create(JClass *clazz) {
    clazz->constantPool.utf8CP = arraylist_create(0);
    clazz->constantPool.classRef = arraylist_create(0);
    clazz->constantPool.stringRef = arraylist_create(0);
    clazz->constantPool.fieldRef = arraylist_create(0);
    clazz->constantPool.methodRef = arraylist_create(0);
    clazz->constantPool.interfaceMethodRef = arraylist_create(0);
}

void constant_list_destroy(JClass *clazz) {
    arraylist_destroy(clazz->constantPool.utf8CP);
    arraylist_destroy(clazz->constantPool.classRef);
    arraylist_destroy(clazz->constantPool.stringRef);
    arraylist_destroy(clazz->constantPool.fieldRef);
    arraylist_destroy(clazz->constantPool.methodRef);
    arraylist_destroy(clazz->constantPool.interfaceMethodRef);
}

void class_clear_refer(PeerClassLoader *cloader, JClass *clazz) {
    s32 i, len;
    if (clazz->field_static) {
        FieldPool *fp = &clazz->fieldPool;
        for (i = 0; i < fp->field_used; i++) {
            FieldInfo *fi = &fp->field[i];
            //        if (utf8_equals_c(fi->name, "zones")) {
            //            s32 debug = 1;
            //        }
            if ((fi->access_flags & ACC_STATIC) != 0 && fi->isrefer) {
                c8 *ptr = getStaticFieldPtr(fi);
                if (ptr) {
                    setFieldRefer(ptr, NULL);
                }
            }
        }
    }
    ArrayList *utf8list = clazz->constantPool.utf8CP;
    for (i = 0, len = utf8list->length; i < len; i++) {
        ConstantUTF8 *cutf = arraylist_get_value(utf8list, i);
        gc_obj_release(cloader->jvm->collector, cutf->jstr);
    }
    gc_obj_release(cloader->jvm->collector, clazz->ins_class);
    clazz->ins_class = NULL;
}

//===============================    Initialization related  ==================================

/* ---------------- unified dispatch table construction ----------------
 *
 * vtable: parent slots are copied (stable indices), an override replaces
 * EVERY slot it legally overrides (not only the first name match), and
 * unmatched dispatchable methods append.  A method that does not legally
 * override an inherited slot (cross-package package-private, private or
 * static participants) leaves that slot untouched, so slot semantics
 * keep the declaring lineage's meaning.
 *
 * itable: every interface owns a read-only signature layout (inherited
 * first, own declarations last); every class gets one row per interface
 * of its closure, each slot filled by the unified selector below or an
 * ISLOT_* status.  Both tables are immutable once the class is
 * CLASS_STATUS_PREPARED. */

static s32 _same_runtime_package(JClass *a, JClass *b) {
    s32 la, lb, i;
    if (a == b) return 1;
    if (!a || !b || a->jloader != b->jloader) return 0;
    /* same package = names share the prefix up to the last '/' */
    la = utf8_last_indexof_c(a->name, "/");
    lb = utf8_last_indexof_c(b->name, "/");
    if (la != lb) return 0;
    if (la < 0) return 1; //both in the default package
    for (i = 0; i < la; i++) {
        if (a->name->data[i] != b->name->data[i]) return 0;
    }
    return 1;
}

/* does `sub` (declared in a subclass) legally override `sup` (occupying
 * an inherited slot)?  Signature match plus JVMS 5.4.5 legality:
 * static/private participants never override, and an inherited
 * package-private method is only overridable within the same runtime
 * package. */
static s32 _method_overrides(MethodInfo *sub, MethodInfo *sup) {
    u16 sub_flags, sup_flags;
    if (sub == sup) return 0;
    if (!utf8_equals(sub->name, sup->name) || !utf8_equals(sub->descriptor, sup->descriptor)) {
        return 0;
    }
    sub_flags = sub->access_flags;
    sup_flags = sup->access_flags;
    if ((sub_flags & ACC_STATIC) || (sub_flags & ACC_PRIVATE)) return 0;
    if ((sup_flags & ACC_STATIC) || (sup_flags & ACC_PRIVATE)) return 0;
    if (sup_flags & ACC_PUBLIC) return 1;
    if (sup_flags & ACC_PROTECTED) return 1; //protected is overridable everywhere for our purposes
    /* package-private: same runtime package only */
    return _same_runtime_package(sub->_this_class, sup->_this_class);
}

static s32 _is_dispatchable(MethodInfo *mi) {
    if ((mi->access_flags & ACC_STATIC) || (mi->access_flags & ACC_PRIVATE)) return 0;
    if (utf8_equals_c(mi->name, "<init>") || utf8_equals_c(mi->name, "<clinit>")) return 0;
    return 1;
}

void class_build_vtable(JClass *clazz) {
    if (clazz->vtable) return;
    if (clazz->cff.access_flags & ACC_INTERFACE) {
        return; //interfaces have no vtable
    }

    JClass *superclass = clazz->superclass;
    s32 super_vtable_len = 0;
    if (superclass) {
        if (!superclass->vtable) {
            // Ensure superclass vtable is built
            class_build_vtable(superclass);
        }
        super_vtable_len = superclass->vtable_length;
    }

    // Estimate max size: super vtable + own methods
    s32 max_len = super_vtable_len + clazz->methodPool.method_used;
    MethodInfo **new_vtable = jvm_calloc(sizeof(MethodInfo *) * max_len);
    if (max_len && !new_vtable) jvm_fatal_oom("vtable", sizeof(MethodInfo *) * max_len);

    // Copy super vtable
    if (superclass && superclass->vtable) {
        memcpy(new_vtable, superclass->vtable, sizeof(MethodInfo *) * super_vtable_len);
    }

    s32 current_len = super_vtable_len;

    s32 i;
    for (i = 0; i < clazz->methodPool.method_used; i++) {
        MethodInfo *mi = &clazz->methodPool.method[i];
        if (!_is_dispatchable(mi)) {
            continue;
        }

        /* replace EVERY slot this method legally overrides; the access
         * check inside _method_overrides keeps cross-package
         * package-private same-signature methods in separate slots */
        s32 j;
        s32 replaced = 0;
        for (j = 0; j < current_len; j++) {
            if (new_vtable[j] && _method_overrides(mi, new_vtable[j])) {
                new_vtable[j] = mi;
                replaced = 1; //keep scanning: an override may replace multiple slots
            }
        }
        if (!replaced) {
            new_vtable[current_len] = mi;
            current_len++;
        }
    }

    /* canonical slot number of each method = the first slot it occupies
     * (call plans and existing readers use it); occupying several slots
     * is fine - the number only has to be stable */
    for (i = 0; i < clazz->methodPool.method_used; i++) {
        clazz->methodPool.method[i]._vtable_index = -1;
    }
    {
        s32 j;
        for (j = 0; j < current_len; j++) {
            MethodInfo *mi = new_vtable[j];
            if (mi && mi->_this_class == clazz && mi->_vtable_index < 0) {
                mi->_vtable_index = j;
            }
        }
    }

    clazz->vtable = new_vtable;
    clazz->vtable_length = current_len;
}

/* does interface `a` extend interface `b` (reflexive)? */
static s32 _iface_extends(JClass *a, JClass *b, Runtime *runtime) {
    s32 i;
    if (a == b) return 1;
    if (!a) return 0;
    for (i = 0; i < a->interfacePool.clasz_used; i++) {
        ConstantClassRef *ccr = (a->interfacePool.clasz + i);
        Utf8String *icl_name = class_get_constant_utf8(a, ccr->stringIndex)->utfstr;
        JClass *icl = classes_load_get_without_resolve(a->jloader, icl_name, runtime);
        if (_iface_extends(icl, b, runtime)) return 1;
    }
    return 0;
}

/* slot layout of one interface: superinterface signatures first (their
 * slot numbers stay stable), own declarations appended, dedup by
 * name+descriptor.  Also assigns each own method's _itable_index (the
 * slot of its signature in ITS declaring interface's layout). */
static void _dispatch_list_push(ArrayList *list, void *value) {
    if (!arraylist_push_back(list, value)) {
        jvm_fatal_oom("dispatch-list", sizeof(void *));
    }
}

static void _iface_layout_build(JClass *clazz, Runtime *runtime) {
    ArrayList *ordered = arraylist_create(8); //JClass*, superinterfaces before self
    s32 i, j;
    if (!ordered) jvm_fatal_oom("interface-order", sizeof(ArrayList));

    if (clazz->iface_layout) {
        arraylist_destroy(ordered);
        return;
    }

    /* collect the superinterface closure depth-first so parents precede
     * children: parent signatures get lower slot numbers */
    {
        ArrayList *work = arraylist_create(8);
        if (!work) jvm_fatal_oom("interface-work", sizeof(ArrayList));
        _dispatch_list_push(work, clazz);
        while (work->length) {
            JClass *cur = (JClass *) arraylist_get_value_unsafe(work, work->length - 1);
            arraylist_remove_at(work, work->length - 1);
            if (arraylist_index_of(ordered, DEFAULT_ARRAYLIST_EQUALS_FUNC, cur) >= 0) {
                continue;
            }
            //insert before any interface that extends cur: simplest is prepend order via reverse walk
            _dispatch_list_push(ordered, cur);
            for (j = 0; j < cur->interfacePool.clasz_used; j++) {
                ConstantClassRef *ccr = (cur->interfacePool.clasz + j);
                Utf8String *icl_name = class_get_constant_utf8(cur, ccr->stringIndex)->utfstr;
                JClass *icl = classes_load_get_without_resolve(cur->jloader, icl_name, runtime);
                if (icl) _dispatch_list_push(work, icl);
            }
        }
        arraylist_destroy(work);
    }
    /* parents must come first: reverse (work collected child-first) */
    for (i = 0; i < ordered->length / 2; i++) {
        void *t = ordered->data[i];
        ordered->data[i] = ordered->data[ordered->length - 1 - i];
        ordered->data[ordered->length - 1 - i] = t;
    }

    {
        IfaceLayout *layout = jvm_calloc(sizeof(IfaceLayout));
        IfaceSlot *slots = NULL;
        s32 count = 0, cap = 0;
        if (!layout) jvm_fatal_oom("interface-layout", sizeof(IfaceLayout));
        for (i = 0; i < ordered->length; i++) {
            JClass *ifc = (JClass *) arraylist_get_value_unsafe(ordered, i);
            cap += ifc->methodPool.method_used;
        }
        if (cap) {
            slots = jvm_calloc(sizeof(IfaceSlot) * cap);
            if (!slots) jvm_fatal_oom("interface-slots", sizeof(IfaceSlot) * cap);
        }

        for (i = 0; i < ordered->length; i++) {
            JClass *ifc = (JClass *) arraylist_get_value_unsafe(ordered, i);
            s32 k;
            for (k = 0; k < ifc->methodPool.method_used; k++) {
                MethodInfo *mi = &ifc->methodPool.method[k];
                if ((mi->access_flags & ACC_STATIC) || (mi->access_flags & ACC_PRIVATE)) {
                    continue;
                }
                s32 found = -1;
                s32 s;
                for (s = 0; s < count; s++) {
                    if (utf8_equals(slots[s].name, mi->name)
                        && utf8_equals(slots[s].descriptor, mi->descriptor)) {
                        found = s;
                        break;
                    }
                }
                if (found < 0) {
                    slots[count].name = mi->name;
                    slots[count].descriptor = mi->descriptor;
                    found = count;
                    count++;
                }
                if (ifc == clazz) {
                    mi->_itable_index = found; //slot of this signature in MY layout
                }
            }
        }
        if (count < cap) {
            IfaceSlot *compact = count ? jvm_malloc(sizeof(IfaceSlot) * count) : NULL;
            if (count && !compact) jvm_fatal_oom("interface-slots", sizeof(IfaceSlot) * count);
            if (count) memcpy(compact, slots, sizeof(IfaceSlot) * count);
            jvm_free(slots);
            slots = compact;
        }
        layout->slot_count = count;
        layout->slots = slots;
        clazz->iface_layout = layout;
    }
    arraylist_destroy(ordered);
}

/*
 * Unified method selection (JVMS 5.4.6, the subset miniJVM enforces):
 * 1) most-derived class declaration of (name, descriptor) wins - an
 *    abstract class declaration beats any default; class participants
 *    must be instance methods. Access is checked after selection.
 * 2) otherwise the maximally-specific default from the interface
 *    closure: exactly one distinct method wins, several incomparable
 *    ones are ISLOT_CONFLICT, none leaves ISLOT_ABSTRACT.
 * Status ISLOT_OK is only returned with a concrete *target.
 */
static MethodInfo *_select_dispatch_method(JClass *receiver, Utf8String *name,
                                           Utf8String *descriptor, s32 require_public,
                                           s32 *status, Runtime *runtime) {
    JClass *c;
    *status = ISLOT_OK;

    /* 1) class hierarchy, most specific first */
    for (c = receiver; c; c = getSuperClass(c)) {
        s32 i;
        MethodPool *fp = &c->methodPool;
        for (i = 0; i < fp->method_used; i++) {
            MethodInfo *mi = &fp->method[i];
            if ((mi->access_flags & ACC_STATIC) || (mi->access_flags & ACC_PRIVATE)) {
                continue; //not inherited participants of interface dispatch
            }
            if (utf8_equals(mi->name, name) && utf8_equals(mi->descriptor, descriptor)) {
                if (require_public && !(mi->access_flags & ACC_PUBLIC)) {
                    *status = ISLOT_ACCESS_ERROR;
                    return mi;
                }
                if (!(mi->access_flags & ACC_ABSTRACT) && (mi->converted_code || mi->is_native)) {
                    return mi;
                }
                /* abstract class declaration: selection stops here -
                 * defaults must not bypass a re-abstraction */
                *status = ISLOT_ABSTRACT;
                return NULL;
            }
        }
    }

    /* 2) maximally-specific interface defaults over the closure */
    {
        MethodInfo *best = NULL;
        s32 concrete_count = 0;
        s32 i, j;
        ArrayList *supers = receiver->supers;
        ArrayList *candidates = arraylist_create(0);
        if (!candidates) jvm_fatal_oom("dispatch-candidates", sizeof(ArrayList));
        /* Keep abstract declarations: they also shadow parent defaults. */
        for (i = 0; supers && i < supers->length; i++) {
            JClass *ifc = (JClass *) arraylist_get_value_unsafe(supers, i);
            s32 k;
            if (!(ifc->cff.access_flags & ACC_INTERFACE)) continue;
            for (k = 0; k < ifc->methodPool.method_used; k++) {
                MethodInfo *mi = &ifc->methodPool.method[k];
                if ((mi->access_flags & ACC_STATIC) || (mi->access_flags & ACC_PRIVATE)) continue;
                if (!utf8_equals(mi->name, name) || !utf8_equals(mi->descriptor, descriptor)) continue;
                if (arraylist_index_of(candidates, DEFAULT_ARRAYLIST_EQUALS_FUNC, mi) < 0) {
                    _dispatch_list_push(candidates, mi);
                }
            }
        }
        for (i = 0; i < candidates->length; i++) {
            MethodInfo *mi = candidates->data[i];
            s32 shadowed = 0;
            for (j = 0; j < candidates->length; j++) {
                MethodInfo *other = candidates->data[j];
                if (other->_this_class != mi->_this_class
                    && _iface_extends(other->_this_class, mi->_this_class, runtime)) {
                    shadowed = 1;
                    break;
                }
            }
            if (!shadowed && !(mi->access_flags & ACC_ABSTRACT)
                && (mi->converted_code || mi->is_native)) {
                best = mi;
                concrete_count++;
            }
        }
        arraylist_destroy(candidates);
        if (concrete_count == 1) return best;
        *status = concrete_count ? ISLOT_CONFLICT : ISLOT_ABSTRACT;
        return NULL;
    }
}

void class_build_itable(JClass *clazz, Runtime *runtime) {
    if (clazz->itable) return;
    if (clazz->cff.access_flags & ACC_INTERFACE) return;

    ArrayList *interfaces = arraylist_create(0);
    s32 i;
    if (!interfaces) jvm_fatal_oom("itable-interfaces", sizeof(ArrayList));
    for (i = 0; i < clazz->supers->length; i++) {
        JClass *sup = arraylist_get_value_unsafe(clazz->supers, i);
        if (!sup) continue;
        if (!(sup->cff.access_flags & ACC_INTERFACE)) continue;
        if (arraylist_index_of(interfaces, DEFAULT_ARRAYLIST_EQUALS_FUNC, sup) < 0) {
            _dispatch_list_push(interfaces, sup);
        }
    }

    s32 itable_len = interfaces->length;
    if (itable_len > 0) {
        Itable *itable = jvm_calloc(sizeof(Itable));
        if (!itable) jvm_fatal_oom("itable", sizeof(Itable));
        itable->interfaces = jvm_calloc(sizeof(JClass *) * itable_len);
        itable->entries = jvm_calloc(sizeof(ItableEntry) * itable_len);
        if (!itable->interfaces || !itable->entries) {
            jvm_fatal_oom("itable-rows", (sizeof(JClass *) + sizeof(ItableEntry)) * itable_len);
        }

        s32 k;
        for (k = 0; k < itable_len; k++) {
            JClass *ic = arraylist_get_value_unsafe(interfaces, k);
            /* the interface's layout must exist: prepare it on demand
             * (class_prepar is idempotent through the status guard) */
            if (!ic->iface_layout) {
                class_prepar(ic->jloader, ic, runtime);
            }
            if (!ic->iface_layout) {
                continue; //unresolvable: row stays zero, dispatch reports not-implemented
            }
            itable->interfaces[k] = ic;
            itable->entries[k].slot_count = ic->iface_layout->slot_count;
            if (ic->iface_layout->slot_count) {
                itable->entries[k].methods = jvm_calloc(sizeof(MethodInfo *) * ic->iface_layout->slot_count);
                itable->entries[k].status = jvm_calloc(ic->iface_layout->slot_count);
                if (!itable->entries[k].methods || !itable->entries[k].status) {
                    jvm_fatal_oom("itable-slots", (sizeof(MethodInfo *) + 1) * ic->iface_layout->slot_count);
                }
            }

            s32 s;
            for (s = 0; s < ic->iface_layout->slot_count; s++) {
                s32 status = ISLOT_ABSTRACT;
                MethodInfo *m = _select_dispatch_method(clazz, ic->iface_layout->slots[s].name,
                                                        ic->iface_layout->slots[s].descriptor, 1, &status, runtime);
                itable->entries[k].methods[s] = m;
                itable->entries[k].status[s] = (u8) status;
            }
        }
        clazz->itable = itable;
        clazz->itable_length = itable_len;
    }
    arraylist_destroy(interfaces);
}

/* ---------------- dispatch plan resolution and target selection ------------- */

s32 resolve_dispatch_plan(Runtime *caller, ConstantMethodRef *cmr, u8 opcode) {
    MethodInfo *m;
    JClass *owner, *symbolic;
    s32 slot;

    /* One constant-pool entry can serve different call opcodes. The plan
     * describes the reference; opcode-specific checks belong to selection. */
    (void) opcode;
    if (dispatch_kind_load(cmr) != DISP_UNRESOLVED) {
        return 0;
    }
    m = cmr->methodInfo;
    if (!m || !m->_this_class) {
        return JVM_EXCEPTION_NOSUCHMETHOD;
    }
    symbolic = classes_load_get_without_resolve(caller->clazz->jloader, cmr->clsName, caller);
    if (!symbolic) return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE;
    owner = m->_this_class;
    if (m->access_flags & ACC_STATIC) return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE;
    if (m->access_flags & ACC_PRIVATE) return JVM_EXCEPTION_ILLEGALACCESS;

    if (!(owner->cff.access_flags & ACC_INTERFACE)) {
        /* class-declared symbolic target (includes Object's methods):
         * dispatch through the receiver vtable, slot from the owner */
        if (owner->status < CLASS_STATUS_PREPARED) {
            class_prepar(owner->jloader, owner, caller);
        }
        slot = m->_vtable_index;
        if (slot < 0 || !owner->vtable) {
            /* private/static/static-initializer target in a virtual site */
            return JVM_EXCEPTION_ILLEGALACCESS;
        }
        cmr->disp_slot = slot;
        cmr->disp_owner = owner;
        cmr->symbolic_owner = symbolic;
        dispatch_kind_store(cmr, DISP_VTABLE);
        return 0;
    }

    /* interface-declared symbolic target (invokeinterface, or a class
     * reference that resolved to an inherited default): dispatch through
     * the receiver's itable row of the SYMBOLIC interface's layout */
    if (symbolic->cff.access_flags & ACC_INTERFACE) owner = symbolic;
    if (!owner->iface_layout) {
        class_prepar(owner->jloader, owner, caller);
    }
    if (!owner->iface_layout) {
        return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE;
    }
    slot = owner == m->_this_class ? m->_itable_index : -1;
    if (slot < 0) {
        /* inherited signature: locate it in the owner's layout; slot
         * numbers of inherited signatures are stable across hierarchy */
        s32 s;
        for (s = 0; s < owner->iface_layout->slot_count; s++) {
            if (utf8_equals(owner->iface_layout->slots[s].name, m->name)
                && utf8_equals(owner->iface_layout->slots[s].descriptor, m->descriptor)) {
                slot = s;
                break;
            }
        }
    }
    if (slot < 0) {
        return JVM_EXCEPTION_NOSUCHMETHOD;
    }
    cmr->disp_slot = slot;
    cmr->disp_owner = owner;
    cmr->symbolic_owner = symbolic;
    dispatch_kind_store(cmr, DISP_ITABLE);
    return 0;
}

s32 select_dispatch_target_resolved(ConstantMethodRef *cmr, Instance *receiver,
                                    u8 opcode, s32 kind, MethodInfo **target) {
    JClass *rc = receiver->mb.clazz;

    *target = NULL;
    /* An inherited method does not erase the constant-pool interface.
     * ITABLE plans use that interface's row, so the row lookup checks it.
     * Object methods use VTABLE and need the separate membership check. */
    if (opcode == op_invokeinterface) {
        if (!(cmr->symbolic_owner->cff.access_flags & ACC_INTERFACE)
            || (kind != DISP_ITABLE && !assignable_from(cmr->symbolic_owner, rc))) {
            return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE;
        }
    }

    if (kind == DISP_VTABLE) {
        MethodInfo *m;
        if (!rc->vtable || cmr->disp_slot < 0 || cmr->disp_slot >= rc->vtable_length) {
            /* receiver hierarchy does not carry the owner's slot */
            return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE;
        }
        m = rc->vtable[cmr->disp_slot];
        if (m && opcode == op_invokeinterface && !(m->access_flags & ACC_PUBLIC)) {
            return JVM_EXCEPTION_ILLEGALACCESS;
        }
        if (!m || (!m->converted_code && !m->is_native)) {
            return JVM_EXCEPTION_ABSTRACTMETHOD;
        }
        *target = m;
        return 0;
    }

    if (kind == DISP_ITABLE) {
        Itable *it = rc->itable;
        s32 i;
        for (i = 0; it && i < rc->itable_length; i++) {
            if (it->interfaces[i] == cmr->disp_owner) {
                ItableEntry *row = &it->entries[i];
                if (cmr->disp_slot >= 0 && cmr->disp_slot < row->slot_count
                    && row->status[cmr->disp_slot] == ISLOT_ACCESS_ERROR) {
                    return JVM_EXCEPTION_ILLEGALACCESS;
                }
                if (cmr->disp_slot < row->slot_count
                    && row->status[cmr->disp_slot] == ISLOT_OK
                    && row->methods[cmr->disp_slot]) {
                    *target = row->methods[cmr->disp_slot];
                    return 0;
                }
                return (row->slot_count && cmr->disp_slot < row->slot_count
                        && row->status[cmr->disp_slot] == ISLOT_CONFLICT)
                           ? JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE
                           : JVM_EXCEPTION_ABSTRACTMETHOD;
            }
        }
        return JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE; //receiver implements no such interface row
    }

    return JVM_EXCEPTION_NOSUCHMETHOD; //DISP_LINK_ERROR
}

s32 select_dispatch_target(Runtime *caller, ConstantMethodRef *cmr, Instance *receiver,
                           u8 opcode, MethodInfo **target) {
    s32 kind = dispatch_kind_load(cmr);
    if (kind == DISP_UNRESOLVED) {
        s32 err;
        spin_lock(&caller->jvm->lock_cloader);
        err = resolve_dispatch_plan(caller, cmr, opcode);
        spin_unlock(&caller->jvm->lock_cloader);
        if (err) {
            *target = NULL;
            return err;
        }
        kind = dispatch_kind_load(cmr);
    }
    return select_dispatch_target_resolved(cmr, receiver, opcode, kind, target);
}

/**
 * It is necessary to initialize the static variable area 
 * and generate instance templates after all classes are loaded into the system
 * @param clazz class
 * @return ret
 */
s32 class_prepar(Instance *loader, JClass *clazz, Runtime *runtime) {
    if (clazz->status >= CLASS_STATUS_PREPARING)return 0;
    clazz->status = CLASS_STATUS_PREPARING;

    s32 ret = 0;
    s32 superid = clazz->cff.super_class;
    if (superid && !clazz->superclass) {
        ConstantClassRef *ccf = class_get_constant_classref(clazz, superid);
        if (ccf) {
            Utf8String *clsName_u = class_get_utf8_string(clazz, ccf->stringIndex);
            JClass *other = classes_load_get_without_resolve(loader, clsName_u, runtime);
            clazz->superclass = other;
        } else {
            jvm_printf("error get superclass , class: %s\n", utf8_cstr(clazz->name));
        }
    }

    find_supers(clazz, runtime);

    s32 i;
    for (i = 0; i < clazz->methodPool.method_used; i++) {
        MethodInfo *mi = &clazz->methodPool.method[i];
        mi->_vtable_index = -1;
        mi->_itable_index = -1;
    }

    //    if (utf8_equals_c(clazz->name, "espresso/parser/JavaParser")) {
    //        int debug = 1;
    //    }

    FieldInfo *f = clazz->fieldPool.field;
    //Calculate the length of different types of variables
    s32 static_len = 0;
    s32 instance_len = 0;
    s32 field_count = clazz->fieldPool.field_used;
    s32 *mem_align_order = jvm_calloc(field_count * sizeof(s32)); //fieldwidth order 8,4,2,1
    s32 order_idx = 0;
    s32 datawidth = 8; //
    //memory align begin
    //Arrange the 8-byte member first, followed by the 4-byte member, then the 2-byte member, and finally the 1-byte member
    while (datawidth > 0) {
        for (i = 0; i < field_count; i++) {
            s32 width = DATA_TYPE_BYTES[f[i].datatype_idx];
            if (width == datawidth) {
                mem_align_order[order_idx] = i;
                order_idx++;
            }
        }
        datawidth /= 2;
    }
    for (i = 0; i < field_count; i++) {
        FieldInfo *fi = &f[mem_align_order[i]];
        s32 width = DATA_TYPE_BYTES[fi->datatype_idx];
        if (fi->access_flags & ACC_STATIC) {
            //Static variables
            fi->offset = static_len;
            static_len += width;
        } else {
            //Instance variables
            fi->offset = instance_len;
            instance_len += width;
        }
        fi->_this_class = clazz;
    }

    jvm_free(mem_align_order);
    s32 align = 8;
    static_len = static_len / align * align + ((static_len % align) > 0 ? align : 0); // 8 byte align
    instance_len = instance_len / align * align + ((instance_len % align) > 0 ? align : 0); // 8 byte align
    //memory align end

    //Static variable allocation
    clazz->field_static_len = static_len;
    if (clazz->field_static_len) {
        clazz->field_static = jvm_calloc(clazz->field_static_len);
    }


    //Generate instance variable template
    if (clazz->superclass) {
        clazz->field_instance_start = clazz->superclass->field_instance_len;
        clazz->field_instance_len = clazz->field_instance_start + instance_len;
        //The instance variable area is preceded by inherited parent class variables, followed by its own variables
        //memcpy((clazz->field_instance_template), (superclass->field_instance_template), clazz->field_instance_start);
    } else {
        clazz->field_instance_start = 0;
        //The instance variable area is preceded by inherited parent class variables, followed by its own variables
        clazz->field_instance_len = clazz->field_instance_start + instance_len;
    }


    //Calculate the offset of class members in advance to improve execution speed
    for (i = 0; i < clazz->fieldPool.field_used; i++) {
        FieldInfo *fi = &clazz->fieldPool.field[i];
        fi->offset_instance = fi->_this_class->field_instance_start + fi->offset;
    }

    ShortCut *jvm_runtime_cache = &runtime->jvm->shortcut;
    //Precompute the offset of fields in instance memory to save runtime time
    if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_CLASS)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_CLASS, STR_FIELD_CLASSHANDLE, "J", NULL, runtime);
        jvm_runtime_cache->class_classHandle = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_CLASS, STR_FIELD_CLASSLOADER, "Ljava/lang/ClassLoader;", NULL, runtime);
        jvm_runtime_cache->class_classLoader = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_STRING)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRING, STR_FIELD_COUNT, "I", NULL, runtime);
        jvm_runtime_cache->string_count = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRING, STR_FIELD_OFFSET, "I", NULL, runtime);
        jvm_runtime_cache->string_offset = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRING, STR_FIELD_VALUE, "[C", NULL, runtime);
        jvm_runtime_cache->string_value = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRING, STR_FIELD_HASH, "I", NULL, runtime);
        jvm_runtime_cache->string_hash = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_STRINGBUILDER)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRINGBUILDER, STR_FIELD_COUNT, "I", NULL, runtime);
        jvm_runtime_cache->stringbuilder_count = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STRINGBUILDER, STR_FIELD_VALUE, "[C", NULL, runtime);
        jvm_runtime_cache->stringbuilder_value = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_THREAD)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_THREAD, STR_FIELD_NAME, "[C", NULL, runtime);
        jvm_runtime_cache->thread_name = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_THREAD, STR_FIELD_STACKFRAME, "J", NULL, runtime);
        jvm_runtime_cache->thread_stackFrame = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_STACKTRACE)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "declaringClass", STR_INS_JAVA_LANG_STRING, NULL, runtime);
        jvm_runtime_cache->stacktrace_declaringClass = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "methodName", STR_INS_JAVA_LANG_STRING, NULL, runtime);
        jvm_runtime_cache->stacktrace_methodName = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "fileName", STR_INS_JAVA_LANG_STRING, NULL, runtime);
        jvm_runtime_cache->stacktrace_fileName = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "lineNumber", "I", NULL, runtime);
        jvm_runtime_cache->stacktrace_lineNumber = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "parent", STR_INS_JAVA_LANG_STACKTRACEELEMENT, NULL, runtime);
        jvm_runtime_cache->stacktrace_parent = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_STACKTRACE, "declaringClazz", STR_INS_JAVA_LANG_CLASS, NULL, runtime);
        jvm_runtime_cache->stacktrace_declaringClazz = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_ORG_MINI_REFLECT_DIRECTMEMOBJ)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_ORG_MINI_REFLECT_DIRECTMEMOBJ, "memAddr", "J", NULL, runtime);
        jvm_runtime_cache->dmo_memAddr = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_ORG_MINI_REFLECT_DIRECTMEMOBJ, "length", "I", NULL, runtime);
        jvm_runtime_cache->dmo_length = fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_ORG_MINI_REFLECT_DIRECTMEMOBJ, "typeDesc", "C", NULL, runtime);
        jvm_runtime_cache->dmo_desc = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_ORG_MINI_REFLECT_REFLECTMETHOD)) {
        FieldInfo *fi;
        fi = find_fieldInfo_by_name_c(STR_CLASS_ORG_MINI_REFLECT_REFLECTMETHOD, "methodId", "J", NULL, runtime);
        jvm_runtime_cache->reflm_methodId = fi;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_BOOLEAN)) {
        jvm_runtime_cache->booleanclass = clazz;
        jvm_runtime_cache->boolean_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_BOOLEAN, "value", "Z", NULL, runtime);
        jvm_runtime_cache->boolean_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_BOOLEAN, "valueOf", "(Z)Ljava/lang/Boolean;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_BYTE)) {
        jvm_runtime_cache->byteclass = clazz;
        jvm_runtime_cache->byte_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_BYTE, "value", "B", NULL, runtime);
        jvm_runtime_cache->byte_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_BYTE, "valueOf", "(B)Ljava/lang/Byte;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_SHORT)) {
        jvm_runtime_cache->shortclass = clazz;
        jvm_runtime_cache->short_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_SHORT, "value", "S", NULL, runtime);
        jvm_runtime_cache->short_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_SHORT, "valueOf", "(S)Ljava/lang/Short;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_CHARACTER)) {
        jvm_runtime_cache->characterclass = clazz;
        jvm_runtime_cache->character_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_CHARACTER, "value", "C", NULL, runtime);
        jvm_runtime_cache->character_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_CHARACTER, "valueOf", "(C)Ljava/lang/Character;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_INTEGER)) {
        jvm_runtime_cache->intclass = clazz;
        jvm_runtime_cache->int_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_INTEGER, "value", "I", NULL, runtime);
        jvm_runtime_cache->int_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_INTEGER, "valueOf", "(I)Ljava/lang/Integer;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_LONG)) {
        jvm_runtime_cache->longclass = clazz;
        jvm_runtime_cache->long_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_LONG, "value", "J", NULL, runtime);
        jvm_runtime_cache->long_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_LONG, "valueOf", "(J)Ljava/lang/Long;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_FLOAT)) {
        jvm_runtime_cache->floatclass = clazz;
        jvm_runtime_cache->float_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_FLOAT, "value", "F", NULL, runtime);
        jvm_runtime_cache->float_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_FLOAT, "valueOf", "(F)Ljava/lang/Float;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_DOUBLE)) {
        jvm_runtime_cache->doubleclass = clazz;
        jvm_runtime_cache->double_value = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_DOUBLE, "value", "D", NULL, runtime);
        jvm_runtime_cache->double_valueOf = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_DOUBLE, "valueOf", "(D)Ljava/lang/Double;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_SUN_MISC_LAUNCHER)) {
        jvm_runtime_cache->launcher_loadClass = find_methodInfo_by_name_c(STR_CLASS_SUN_MISC_LAUNCHER, "loadClass", "(Ljava/lang/String;Ljava/lang/ClassLoader;)Ljava/lang/Class;", NULL, runtime);
        jvm_runtime_cache->launcher_getSystemClassLoader = find_methodInfo_by_name_c(STR_CLASS_SUN_MISC_LAUNCHER, "getSystemClassLoader", "()Ljava/lang/ClassLoader;", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_REF_REFERENCE)) {
        jvm_runtime_cache->reference_target = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_REF_REFERENCE, "target", STR_INS_JAVA_LANG_OBJECT, NULL, runtime);
        jvm_runtime_cache->reference_target->is_ref_target = 1; //mark as weakreference.target field
        jvm_runtime_cache->reference_vmEnqueneReference = find_methodInfo_by_name_c(STR_CLASS_JAVA_LANG_REF_REFERENCE, "vmEnqueneReference", "(Ljava/lang/ref/Reference;)V", NULL, runtime);
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_REF_WEAKREFERENCE)) {
        jvm_runtime_cache->weakreference = clazz;
    } else if (utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_THROWABLE)) {
        jvm_runtime_cache->throwable_detailMessage = find_fieldInfo_by_name_c(STR_CLASS_JAVA_LANG_THROWABLE, "detailMessage", STR_INS_JAVA_LANG_STRING, NULL, runtime);
    }
    // mark class if it is son of classloader
    if (!utf8_equals_c(clazz->name, STR_CLASS_JAVA_LANG_CLASSLOADER)) {
        JClass *cl_clazz = classes_get_c(runtime->jvm, NULL, STR_CLASS_JAVA_LANG_CLASSLOADER);
        if (assignable_from(cl_clazz, clazz)) {
            clazz->is_jcloader = 1;
        }
    }
    //mark class if it's son of weakreference
    JClass *weak_clazz = classes_get_c(runtime->jvm, NULL, STR_CLASS_JAVA_LANG_REF_WEAKREFERENCE);
    if (assignable_from(weak_clazz, clazz)) {
        clazz->is_weakref = 1;
    }

    //    jvm_printf("prepared: %s\n", utf8_cstr(clazz->name));

    class_build_vtable(clazz);
    if (clazz->cff.access_flags & ACC_INTERFACE) {
        /* interface: own signature layout instead of dispatch tables */
        _iface_layout_build(clazz, runtime);
    } else {
        class_build_itable(clazz, runtime);
    }

    clazz->status = CLASS_STATUS_PREPARED;
    return ret;
}

/**
 * To execute static code, you need to load the bytecode into the class
 * and initialize the static variable area.
 * @param clazz class
 * @param runtime  runtime
 */
void class_clinit(JClass *clazz, Runtime *runtime) {
    vm_share_lock(runtime->jvm);
    runtime->thrd_info->no_pause++;
    if (clazz->status < CLASS_STATUS_PREPARED) {
        class_prepar(clazz->jloader, clazz, runtime);
    }
    if (clazz->status < CLASS_STATUS_CLINITING) {
        clazz->status = CLASS_STATUS_CLINITING;

        s32 i, len;

        /**
         * Convert some index references to memory object references to speed up bytecode execution
         * Point ConstantMethodRef.index to a specific MethodInfo, which may be in this class or in a parent class
         * Point ConstantFieldRef.index to the specific FieldInfo memory
         * @param clazz
         */
        for (i = 0; i < clazz->constantPool.methodRef->length; i++) {
            ConstantMethodRef *cmr = (ConstantMethodRef *) arraylist_get_value(clazz->constantPool.methodRef, i);
            // if (utf8_equals_c(cmr->name, "getClass")
            //     &&
            //     utf8_equals_c(cmr->clsName, "java/lang/Object")
            //         ) {
            //     s32 debug = 1;
            // }

            cmr->methodInfo = find_methodInfo_by_methodref(clazz, cmr->item.index, runtime);
        }

        for (i = 0; i < clazz->constantPool.interfaceMethodRef->length; i++) {
            ConstantMethodRef *cmr = (ConstantMethodRef *) arraylist_get_value(clazz->constantPool.interfaceMethodRef, i);
            cmr->methodInfo = find_methodInfo_by_methodref(clazz, cmr->item.index, runtime);
        }

        for (i = 0; i < clazz->constantPool.fieldRef->length; i++) {
            ConstantFieldRef *cfr = (ConstantFieldRef *) arraylist_get_value(clazz->constantPool.fieldRef, i);
            FieldInfo *fi = find_fieldInfo_by_fieldref(clazz, cfr->item.index, runtime);
            cfr->fieldInfo = fi;
            if (!fi) {
                jvm_printf("field not found %s.%s \n", utf8_cstr(class_get_constant_classref(clazz, cfr->classIndex)->name), utf8_cstr(class_get_constant_utf8(clazz, class_get_constant_name_and_type(clazz, cfr->nameAndTypeIndex)->nameIndex)->utfstr));
                fi = find_fieldInfo_by_fieldref(clazz, cfr->item.index, runtime);
            }
            if (fi->_this_class->status < CLASS_STATUS_CLINITED) {
                //class_clinit(fi->_this_class, runtime); //init here would too early
            }
        }
        //find finalize method, but not process java.lang.Object.finalize()
        clazz->finalizeMethod = find_methodInfo_by_name_c(utf8_cstr(clazz->name), STR_METHOD_FINALIZE, "()V", clazz->jloader, runtime);
        if (clazz->finalizeMethod && utf8_equals_c(clazz->finalizeMethod->_this_class->name, STR_CLASS_JAVA_LANG_OBJECT)) {
            clazz->finalizeMethod = NULL;
        } else {
            s32 debug = 1;
        }

        // init javastring
        ArrayList *strlist = clazz->constantPool.stringRef;
        for (i = 0, len = strlist->length; i < len; i++) {
            ConstantStringRef *strRef = arraylist_get_value_unsafe(strlist, i);
            ConstantUTF8 *cutf = class_get_constant_utf8(clazz, strRef->stringIndex);
            Instance *jstr = hashtable_get(runtime->jvm->table_jstring_const, cutf->utfstr);
            if (!jstr) {
                jstr = jstring_create(cutf->utfstr, runtime);
                Utf8String *ustr = utf8_create_copy(cutf->utfstr);
                hashtable_put(runtime->jvm->table_jstring_const, ustr, jstr);
                gc_obj_hold(runtime->jvm->collector, jstr);
            }
            cutf->jstr = jstr;
        }

        for (i = 0; i < clazz->fieldPool.field_used; i++) {
            FieldInfo *fi = &clazz->fieldPool.field[i];
            if (fi->const_value_item && (fi->access_flags & ACC_STATIC)) {
                //except no static field of class: final int a=3;
                c8 *ptr = getStaticFieldPtr(fi);
                // check variable type to determain long/s32/f64/f32
                s32 datatype = fi->datatype_idx;
                //value type
                switch (datatype) {
                    case DATATYPE_BOOLEAN:
                    case DATATYPE_BYTE: {
                        setFieldByte(ptr, (s8) ((ConstantInteger *) fi->const_value_item)->value);
                        break;
                    }
                    case DATATYPE_SHORT:
                    case DATATYPE_JCHAR: {
                        setFieldShort(ptr, (s16) ((ConstantInteger *) fi->const_value_item)->value);
                        break;
                    }
                    case DATATYPE_INT: {
                        setFieldInt(ptr, ((ConstantInteger *) fi->const_value_item)->value);
                        break;
                    }
                    case DATATYPE_FLOAT: {
                        setFieldFloat(ptr, ((ConstantFloat *) fi->const_value_item)->value);
                        break;
                    }
                    case DATATYPE_LONG: {
                        setFieldLong(ptr, ((ConstantLong *) fi->const_value_item)->value);
                        break;
                    }
                    case DATATYPE_DOUBLE: {
                        setFieldDouble(ptr, ((ConstantDouble *) fi->const_value_item)->value);
                        break;
                    }
                    default: {
                        if (utf8_equals_c(fi->descriptor, STR_INS_JAVA_LANG_STRING)) {
                            //垃圾回收标识
                            setFieldRefer(ptr, class_get_constant_utf8(fi->_this_class, ((ConstantStringRef *) fi->const_value_item)->stringIndex)->jstr);
                        } else {
                        }
                    }
                }
            }
        }

        //Initialize the base class first
        JClass *superclass = getSuperClass(clazz);
        if (superclass && superclass->status < CLASS_STATUS_CLINITED) {
            class_clinit(superclass, runtime);
        }

        MethodPool *p = &(clazz->methodPool);
        for (i = 0; i < p->method_used; i++) {
            //jvm_printf("%s,%s\n", utf8_cstr(p->methodRef[i].name), utf8_cstr(p->methodRef[i].descriptor));
            MethodInfo *mi = &(p->method[i]);
            if (utf8_equals_c(mi->name, STR_METHOD_CLINIT)) {
                s32 ret = execute_method_impl(mi, runtime);
                if (ret == RUNTIME_STATUS_EXCEPTION) {
                    print_exception(runtime);
                }
                //jvm_printf("clinit %s.%s\n", utf8_cstr(clazz->name), utf8_cstr(mi->name));
                break;
            }
        }
#if _JVM_DEBUG_LOG_LEVEL > 2
        //jvm_printf("hold class %s\n", utf8_cstr(clazz->name));
#endif
        clazz->status = CLASS_STATUS_CLINITED;
    }
    runtime->thrd_info->no_pause--;
    vm_share_unlock(runtime->jvm);
}


//===============================    Instantiation related  ==================================

u8 instance_of(Instance *ins, JClass *other) {
    return ins && assignable_from(other, ins->mb.clazz);
}

u8 isSonOfInterface(JClass *clazz, JClass *son, Runtime *runtime) {
    s32 i;
    for (i = 0; i < son->interfacePool.clasz_used; i++) {
        ConstantClassRef *ccr = (son->interfacePool.clasz + i);
        JClass *other = classes_load_get_with_clinit(son->jloader, class_get_constant_utf8(son, ccr->stringIndex)->utfstr, runtime);
        if (clazz == other) {
            return 1;
        } else {
            u8 sure = isSonOfInterface(clazz, other, runtime);
            if (sure)return 1;
        }
    }
    return 0;
}

u8 assignable_from(JClass *clazzParent, JClass *clazzSon) {
    if (!clazzParent || !clazzSon) return 0;
    if (clazzParent == clazzSon) return 1;

    u8 parent_is_array = clazzParent->name && utf8_char_at(clazzParent->name, 0) == '[';
    u8 son_is_array = clazzSon->name && utf8_char_at(clazzSon->name, 0) == '[';
    if (son_is_array) {
        if (!parent_is_array) {
            return utf8_equals_c(clazzParent->name, STR_CLASS_JAVA_LANG_OBJECT)
                   || utf8_equals_c(clazzParent->name, "java/lang/Cloneable")
                   || utf8_equals_c(clazzParent->name, "java/io/Serializable");
        }

        JClass *parent_component = clazzParent->component_class;
        JClass *son_component = clazzSon->component_class;
        if (!parent_component || !son_component) return 0;
        if (parent_component->is_primitive || son_component->is_primitive) {
            return parent_component == son_component;
        }
        return assignable_from(parent_component, son_component);
    }
    if (parent_is_array) return 0;

    s32 i, imax;
    for (i = 0, imax = clazzSon->supers->length; i < imax; i++) {
        JClass *cl = clazzSon->supers->data[i];
        if (clazzParent == cl) {
            return 1;
        }
    }
    return 0;
}

JClass *getSuperClass(JClass *clazz) {
    return clazz->superclass;
}

//===============================    Class Data Access  ==================================


JClass *getClassByConstantClassRef(JClass *clazz, s32 index, Runtime *runtime) {
    ConstantClassRef *ccf = class_get_constant_classref(clazz, index);
    if (!ccf->clazz) {
        Utf8String *clsName = class_get_utf8_string(clazz, ccf->stringIndex);
        ccf->clazz = classes_load_get_with_clinit(clazz->jloader, clsName, runtime);
    }
    return ccf->clazz;
}


/**
 * Get class member information. Member information has the following situations
 * ConstantFieldRef：
 * The static and instance members of the parent class, Father.x , are described as Son.x , and the class name is described as this class.
 * Calling static variables of other classes (non-parent classes), such as System.out, will be described as System.out, and the class name will be described as other classes.
 *
 * @param clazz class
 * @param field_ref ref
 * @return fi
 */
FieldInfo *find_fieldInfo_by_fieldref(JClass *clazz, s32 field_ref, Runtime *runtime) {
    ConstantFieldRef *cfr = class_get_constant_fieldref(clazz, field_ref);
    ConstantNameAndType *nat = class_get_constant_name_and_type(clazz, cfr->nameAndTypeIndex);
    Utf8String *clsName = class_get_utf8_string(clazz, class_get_constant_classref(clazz, cfr->classIndex)->stringIndex);
    Utf8String *fieldName = class_get_utf8_string(clazz, nat->nameIndex);
    Utf8String *type = class_get_utf8_string(clazz, nat->typeIndex);
    return find_fieldInfo_by_name(clsName, fieldName, type, clazz->jloader, runtime);
}

FieldInfo *find_fieldInfo_by_name_c(c8 const *pclsName, c8 const *pfieldName, c8 const *pfieldType, Instance *jloader, Runtime *runtime) {
    Utf8String *clsName = utf8_create_c(pclsName);
    Utf8String *fieldName = utf8_create_c(pfieldName);
    Utf8String *fieldType = utf8_create_c(pfieldType);
    FieldInfo *fi = find_fieldInfo_by_name(clsName, fieldName, fieldType, jloader, runtime);
    utf8_destroy(clsName);
    utf8_destroy(fieldName);
    utf8_destroy(fieldType);
    return fi;
}

FieldInfo *find_fieldInfo_by_name(Utf8String *clsName, Utf8String *fieldName, Utf8String *fieldType, Instance *jloader, Runtime *runtime) {
    FieldInfo *fi = NULL;
    JClass *other = classes_load_get_without_resolve(jloader, clsName, runtime);
    //    if (utf8_equals_c(clsName, "espresso/parser/JavaParser")&&utf8_equals_c(fieldName, "methodNode_d")) {
    //        int debug = 1;
    //    }
    if (!other) {
        jvm_printf("field not exist :%s.%s%s\n", utf8_cstr(clsName), utf8_cstr(fieldName), utf8_cstr(fieldType));
        return NULL;
    }

    while (fi == NULL && other) {
        FieldPool *fp = &(other->fieldPool);
        s32 i = 0;
        for (; i < fp->field_used; i++) {
            FieldInfo *tmp = &fp->field[i];
            if (utf8_equals(fieldName, tmp->name) == 1
                && utf8_equals(fieldType, tmp->descriptor) == 1
            ) {
                fi = tmp;
                break;
            }
        }
        //find interface default field
        if (fi == NULL) {
            for (i = 0; i < other->interfacePool.clasz_used; i++) {
                ConstantClassRef *ccr = (other->interfacePool.clasz + i);
                Utf8String *icl_name = class_get_constant_utf8(other, ccr->stringIndex)->utfstr;
                //                if (utf8_equals_c(icl_name, "java/util/List")&&utf8_equals_c(methodName, "size")) {
                //                    int debug = 1;
                //                }
                FieldInfo *ifi = find_fieldInfo_by_name(icl_name, fieldName, fieldType, jloader, runtime);
                if (ifi != NULL) {
                    fi = ifi;
                    break;
                }
            }
        }
        other = getSuperClass(other);
    }

    return fi;
}


/**
 * Find the instance method, invokevirtual
 * @param ins ins
 * @param methodName name
 * @param methodType type
 * @return mi
 */
MethodInfo *find_instance_methodInfo_by_name(Instance *ins, Utf8String *methodName, Utf8String *methodType, Runtime *runtime) {
    if (!ins)return NULL;
    return find_methodInfo_by_name(ins->mb.clazz->name, methodName, methodType, ins->mb.clazz->jloader, runtime);
}

MethodInfo *find_methodInfo_by_methodref(JClass *clazz, s32 method_ref, Runtime *runtime) {
    ConstantMethodRef *cmr = class_get_constant_method_ref(clazz, method_ref);
    Utf8String *clsName = cmr->clsName;
    Utf8String *methodName = cmr->name;
    Utf8String *methodType = cmr->descriptor;
    return find_methodInfo_by_name(clsName, methodName, methodType, clazz->jloader, runtime);
}

MethodInfo *find_methodInfo_by_name_c(c8 const *pclsName, c8 const *pmethodName, c8 const *pmethodType, Instance *jloader, Runtime *runtime) {
    Utf8String *clsName = utf8_create_c(pclsName);
    Utf8String *methodName = utf8_create_c(pmethodName);
    Utf8String *methodType = utf8_create_c(pmethodType);
    MethodInfo *mi = find_methodInfo_by_name(clsName, methodName, methodType, jloader, runtime);
    utf8_destroy(clsName);
    utf8_destroy(methodName);
    utf8_destroy(methodType);
    return mi;
}

static MethodInfo *find_declared_method(JClass *clazz, Utf8String *methodName, Utf8String *methodType) {
    MethodPool *fp = &(clazz->methodPool);
    s32 i;
    for (i = 0; i < fp->method_used; i++) {
        MethodInfo *tmp = &fp->method[i];
        if (utf8_equals(methodName, tmp->name) == 1
            && utf8_equals(methodType, tmp->descriptor) == 1) {
            if (!tmp->_this_class) {
                tmp->_this_class = clazz;
            }
            return tmp;
        }
    }
    return NULL;
}

static MethodInfo *find_method_in_interface_tree(JClass *clazz, Utf8String *methodName, Utf8String *methodType, Runtime *runtime, s32 requireCode) {
    MethodInfo *mi = find_declared_method(clazz, methodName, methodType);
    s32 i;
    if (mi != NULL) {
        if (!requireCode || mi->converted_code != NULL) {
            return mi;
        }
    }

    for (i = 0; i < clazz->interfacePool.clasz_used; i++) {
        ConstantClassRef *ccr = (clazz->interfacePool.clasz + i);
        Utf8String *icl_name = class_get_constant_utf8(clazz, ccr->stringIndex)->utfstr;
        JClass *icl = classes_load_get_without_resolve(clazz->jloader, icl_name, runtime);
        mi = find_method_in_interface_tree(icl, methodName, methodType, runtime, requireCode);
        if (mi != NULL) {
            return mi;
        }
    }
    return NULL;
}

MethodInfo *find_methodInfo_by_name(Utf8String *clsName, Utf8String *methodName, Utf8String *methodType, Instance *jloader, Runtime *runtime) {
    MethodInfo *mi = NULL;
    JClass *start = classes_load_get_without_resolve(jloader, clsName, runtime);
    JClass *other = start;
    if (!other) {
        jvm_printf("method not exist :%s.%s%s\n", utf8_cstr(clsName), utf8_cstr(methodName), utf8_cstr(methodType));
        return NULL;
    }

    if (start->cff.access_flags & ACC_INTERFACE) {
        /* JVMS 5.4.3.4: own declaration, then public instance Object
         * methods, then superinterfaces. Object is not a superinterface. */
        mi = find_declared_method(start, methodName, methodType);
        if (mi) return mi;
        Utf8String *object_name = utf8_create_c(STR_CLASS_JAVA_LANG_OBJECT);
        JClass *object = classes_load_get_without_resolve(NULL, object_name, runtime);
        utf8_destroy(object_name);
        if (object) {
            mi = find_declared_method(object, methodName, methodType);
            if (mi && (mi->access_flags & ACC_PUBLIC) && !(mi->access_flags & ACC_STATIC)) return mi;
        }
        return find_method_in_interface_tree(start, methodName, methodType, runtime, 0);
    }

    while (mi == NULL && other) {
        mi = find_declared_method(other, methodName, methodType);
        other = getSuperClass(other);
    }

    other = start;
    while (mi == NULL && other) {
        s32 i;
        for (i = 0; i < other->interfacePool.clasz_used; i++) {
            ConstantClassRef *ccr = (other->interfacePool.clasz + i);
            Utf8String *icl_name = class_get_constant_utf8(other, ccr->stringIndex)->utfstr;
            JClass *icl = classes_load_get_without_resolve(jloader, icl_name, runtime);
            mi = find_method_in_interface_tree(icl, methodName, methodType, runtime, 1);
            if (mi != NULL) {
                break;
            }
        }
        other = getSuperClass(other);
    }
    return mi;
}


/**
 * find all superclass and interfaces ,put they in supers,
 * @param clazz
 * @param runtime
 * @return
 */

static void find_supers_impl(JClass *clazz, Runtime *runtime, ArrayList *list) {
    JClass *other = clazz;
    s32 i;
    while (other) {
        if (arraylist_index_of(list, DEFAULT_ARRAYLIST_EQUALS_FUNC, other) < 0) {
            arraylist_push_back(list, other);
        }

        //find interface default method implementation JDK8
        for (i = 0; i < other->interfacePool.clasz_used; i++) {
            ConstantClassRef *ccr = (other->interfacePool.clasz + i);
            Utf8String *icl_name = class_get_constant_utf8(other, ccr->stringIndex)->utfstr;
            JClass *icl = classes_load_get_without_resolve(other->jloader, icl_name, runtime);
            find_supers_impl(icl, runtime, list); //find interface's interfaces
        }
        //find superclass
        other = getSuperClass(other);
    }
}

void find_supers(JClass *clazz, Runtime *runtime) {
    find_supers_impl(clazz, runtime, clazz->supers);
}

/* Get Major Version String */
c8 *getMajorVersionString(u16 major_number) {
    if (major_number == 0x33)
        return "J2SE 7";
    if (major_number == 0x32)
        return "J2SE 6.0";
    return "NONE";
}
