#include "jvm.h"
#include "jvm_util.h"
#include "jit.h"
#include "garbage.h"


/* ==================================opcode implementation =============================*/


void _op_notsupport(u8 *opCode, Runtime *runtime) {
    invoke_deepth(runtime);
    jvm_printf("not support instruct [%x]\n", opCode[0]);
    exit(2);
}

//----------------------------------  tool func  ------------------------------------------


s32 exception_handle(RuntimeStack *stack, Runtime *runtime) {
    Instance *ins = pop_ref(stack);
    CodeAttribute *ca = runtime->method->converted_code;

#if _JVM_DEBUG_LOG_LEVEL > 3
    JClass *clazz = runtime->clazz;
    s32 lineNum = getLineNumByIndex(runtime->method->converted_code, (s32) (runtime->pc - runtime->method->converted_code->code));
    jvm_printf("Exception   at %s.%s(%s.java:%d)\n",
               utf8_cstr(clazz->name), utf8_cstr(runtime->method->name),
               utf8_cstr(clazz->name),
               lineNum
    );
#endif
    s32 index = 0;
    ExceptionTable *et = NULL; // _find_exception_handler(runtime, ins, ca, (s32) (runtime->pc - ca->code), &index);
    s32 offset = (s32) (runtime->pc - ca->code);
    s32 i;
    ExceptionTable *e = ca->exception_table;
    for (i = 0; i < ca->exception_table_length; i++) {
        if (offset >= (e + i)->start_pc
            && offset < (e + i)->end_pc) {
            if (!(e + i)->catch_type) {
                et = e + i;
                index = i;
                break;
            }
            ConstantClassRef *ccr = class_get_constant_classref(runtime->clazz, (e + i)->catch_type);
            JClass *catchClass = classes_load_get_with_clinit(runtime->clazz->jloader, ccr->name, runtime);
            if (instance_of(ins, catchClass)) {
                et = e + i;
                index = i;
                break;
            }
        }
    }
    if (et == NULL) {
        localvar_dispose(runtime);
        push_ref(stack, ins);
        return 0;
    } else {
        /* JVM spec: entering a catch handler clears the operand stack and
         * pushes only the exception reference; locals survive.  The clear
         * must target the operand region (above the locals slots) - NOT
         * localvar_dispose, whose push would land on local 0 and clobber
         * `this`.  This also stops boundary-thrown invokes (NPE with no
         * callee frame to consume the args) from leaking the argument
         * slots once per caught iteration. */
        stack->sp = runtime->localvar + runtime->localvar_slots;
        push_ref(stack, ins);
#if _JVM_DEBUG_LOG_LEVEL > 3
        jvm_printf("Exception : %s\n", utf8_cstr(ins->mb.clazz->name));
#endif
        runtime->pc = (ca->code + et->handler_pc);
        jit_set_exception_jump_addr(runtime, ca, index);
        return 1;
    }
}

s32 _jarray_check_exception(Instance *arr, s32 index, Runtime *runtime) {
    if (!arr) {
        Instance *exception = exception_create(JVM_EXCEPTION_NULLPOINTER, runtime);
        push_ref(runtime->stack, (__refer) exception);
    } else if (index >= jarray_length(arr) || index < 0) {
        Instance *exception = exception_create(JVM_EXCEPTION_ARRAYINDEXOUTOFBOUNDS, runtime);
        push_ref(runtime->stack, (__refer) exception);
    } else {
        return RUNTIME_STATUS_NORMAL;
    }
    return RUNTIME_STATUS_EXCEPTION;
}

void _outofbounds_throw_exception(RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create(JVM_EXCEPTION_ARRAYINDEXOUTOFBOUNDS, runtime);
    push_ref(runtime->stack, (__refer) exception);
}

void _null_throw_exception(RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create(JVM_EXCEPTION_NULLPOINTER, runtime);
    push_ref(stack, (__refer) exception);
}

void _nosuchmethod_check_exception(c8 const *mn, RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create_str(JVM_EXCEPTION_NOSUCHMETHOD, runtime, mn);
    push_ref(stack, (__refer) exception);
}

void _nosuchfield_check_exception(c8 const *mn, RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create_str(JVM_EXCEPTION_NOSUCHFIELD, runtime, mn);
    push_ref(stack, (__refer) exception);
}

void _arrithmetic_throw_exception(RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create(JVM_EXCEPTION_ARRITHMETIC, runtime);
    push_ref(stack, (__refer) exception);
}

void _checkcast_throw_exception(RuntimeStack *stack, Runtime *runtime) {
    Instance *exception = exception_create(JVM_EXCEPTION_CLASSCAST, runtime);
    push_ref(stack, (__refer) exception);
}


static s32 filterClassName(Utf8String *clsName) {
    if (utf8_indexof_c(clsName, "com/sun") < 0
        && utf8_indexof_c(clsName, "java/") < 0
        && utf8_indexof_c(clsName, "javax/") < 0) {
        return 1;
    }
    return 0;
}

#define check_gc_pause(offset){\
    if (offset < 0 && r->thrd_info->suspend_count) {\
        \
        r->stack->sp = sp;\
        check_suspend_and_pause(r);\
    }\
    /* OSR probe: the heat test stays inline so cold loops pay only the\n\
     * counter increment; the call happens past the threshold only */\
    if (offset < 0 && JIT_ENABLE\
        && ca->jit.interpreted_count++ > JIT_COMPILE_EXEC_COUNT\
        && osr_hot_backedge(r, ca, (s32)(offset), sp, &ret)) goto label_osr_exit;\
}

#if JIT_ENABLE
/*
 * On-stack replacement attempt, called at a backward branch once the
 * method's backedge/entry counter passed the compile threshold.  Returns
 * 1 when the live frame was transferred into the compiled body (the
 * trampoline call ran the method to completion): *retp then holds the
 * body's final RUNTIME_STATUS and the shared stack carries its result at
 * (sp - return_slots), so the caller must exit through label_osr_exit.
 * Only javac-shaped loops qualify: the backward target must see an empty
 * operand stack, because the compiled code models the operand region from
 * base+max_locals upward.
 */
static s32 osr_hot_backedge(Runtime *r, CodeAttribute *ca, s32 offset, StackEntry *sp, s32 *retp) {
    s32 ret;

    if (offset == -1 || !ca) {
        /* -1 is the jdwp per-instruction probe */
        return 0;
    }
    if (r->jvm->jdwp_enable) {
        return 0;
    }
    if (ca->jit.state == JIT_GEN_ERROR) {
        return 0; /* gave up compiling: probe forever cheap */
    }
    /* empty operand stack at the loop header: all loop state in locals */
    if (sp != r->localvar + r->localvar_slots) {
        return 0;
    }
    /* the trampoline loads SP/locals from the shared state */
    r->stack->sp = sp;
    ret = jit_osr_execute(r, (s32) (r->pc - ca->code));
    if (ret < 0) {
        return 0;
    }
    *retp = ret;
    return 1;
}
#else
static s32 osr_hot_backedge(Runtime *r, CodeAttribute *ca, s32 offset, StackEntry *sp, s32 *retp) {
    return 0;
}
#endif

s32 invokedynamic_prepare(Runtime *runtime, BootstrapMethod *bootMethod, ConstantInvokeDynamic *cid) {
    // =====================================================================
    //         run bootstrap method java.lang.invoke.LambdaMetafactory
    //
    //         public static CallSite metafactory(
    //                   MethodHandles.Lookup caller,
    //                   String invokedName,
    //                   MethodType invokedType,
    //                   MethodType samMethodType,
    //                   MethodHandle implMethod,
    //                   MethodType instantiatedMethodType
    //                   )
    //          public static CallSite altMetafactory(
    //                   MethodHandles.Lookup caller,
    //                   String invokedName,
    //                   MethodType invokedType,
    //                   MethodType methodType,
    //                   MethodHandle methodImplementation,
    //                   MethodType instantiatedMethodType,
    //                   int flags,
    //                   int markerInterfaceCount,  // IF flags has MARKERS set
    //                   Class... markerInterfaces, // IF flags has MARKERS set
    //                   int bridgeCount,           // IF flags has BRIDGES set
    //                   MethodType... bridges      // IF flags has BRIDGES set
    //                 )
    //
    //          to generate Lambda Class implementation specify interface
    //          and new a callsite
    // =====================================================================
    JClass *clazz = runtime->clazz;
    RuntimeStack *stack = runtime->stack;

    //parper bootMethod parameter
    Instance *lookup = method_handles_lookup_create(runtime, clazz);
    push_ref(stack, lookup); //lookup

    Utf8String *ustr_invokeName = class_get_constant_utf8(clazz, class_get_constant_name_and_type(clazz, cid->nameAndTypeIndex)->nameIndex)->utfstr;
    Instance *jstr_invokeName = jstring_create(ustr_invokeName, runtime);
    push_ref(stack, jstr_invokeName); //invokeName

    Utf8String *ustr_invokeType = class_get_constant_utf8(clazz, class_get_constant_name_and_type(clazz, cid->nameAndTypeIndex)->typeIndex)->utfstr;
    Instance *mt_invokeType = method_type_create(runtime, clazz->jloader, ustr_invokeType);
    push_ref(stack, mt_invokeType); //invokeMethodType

    //other bootMethod parameter

    //if bootMethod->num_bootstrap_arguments <= 3 call metafactory, if >3 call altMetafactory.
    Instance *more_args = NULL;
    s32 args_cnt = bootMethod->num_bootstrap_arguments;
    static const s32 ALT_PARA = 3;
    if (args_cnt > ALT_PARA) {
        Utf8String *ustr = utf8_create_c(STR_INS_JAVA_LANG_OBJECT);
        more_args = jarray_create_by_type_name(runtime, args_cnt, ustr, clazz->jloader);
        utf8_destroy(ustr);

        if (!more_args) return exception_throw_out_of_memory(runtime);

        push_ref(stack, more_args);
    }
    s32 i;
    for (i = 0; i < args_cnt; i++) {
        ConstantItem *item = class_get_constant_item(clazz, bootMethod->bootstrap_arguments[i]);
        switch (item->tag) {
            case CONSTANT_METHOD_TYPE: {
                ConstantMethodType *cmt = (ConstantMethodType *) item;
                Utf8String *arg = class_get_constant_utf8(clazz, cmt->descriptor_index)->utfstr;
                Instance *mt = method_type_create(runtime, clazz->jloader, arg);
                if (args_cnt <= ALT_PARA) {
                    push_ref(stack, mt);
                } else {
                    jarray_set_field(more_args, i, (s64) (intptr_t) mt);
                }
                break;
            }
            case CONSTANT_STRING_REF: {
                ConstantStringRef *csr = (ConstantStringRef *) item;
                Utf8String *arg = class_get_constant_utf8(clazz, csr->stringIndex)->utfstr;
                Instance *spec = jstring_create(arg, runtime);
                if (args_cnt <= ALT_PARA) {
                    push_ref(stack, spec);
                } else {
                    jarray_set_field(more_args, i, (s64) (intptr_t) spec);
                }
                break;
            }
            case CONSTANT_METHOD_HANDLE: {
                ConstantMethodHandle *cmh = (ConstantMethodHandle *) item;
                MethodInfo *mip = find_methodInfo_by_methodref(clazz, cmh->reference_index, runtime);
                Instance *mh = method_handle_create(runtime, mip, cmh->reference_kind);
                if (args_cnt <= ALT_PARA) {
                    push_ref(stack, mh);
                } else {
                    jarray_set_field(more_args, i, (s64) (intptr_t) mh);
                }
                break;
            }
            case CONSTANT_INTEGER: {
                ConstantInteger *ci = (ConstantInteger *) item;
                push_int(stack, ci->value);
                s32 ret = execute_method_impl(runtime->jvm->shortcut.int_valueOf, runtime);
                if (ret != RUNTIME_STATUS_NORMAL) {
                    _null_throw_exception(stack, runtime);
                    return RUNTIME_STATUS_EXCEPTION;
                }
                if (args_cnt <= ALT_PARA) {
                } else {
                    Instance *ins = pop_ref(stack);
                    jarray_set_field(more_args, i, (s64) (intptr_t) ins);
                }
                break;
            }
            default: {
                jvm_printf("invokedynamic para parse error. para type: %d", item->tag);

                if (args_cnt <= ALT_PARA) {
                    StackEntry entry;
                    entry.lvalue = 0;
                    entry.rvalue = NULL;
                    push_entry(stack, &entry);
                } else {
                    jarray_set_field(more_args, i, 0);
                }
            }
        }
    }

    //get bootmethod
    MethodInfo *boot_m = find_methodInfo_by_methodref(clazz, class_get_method_handle(clazz, bootMethod->bootstrap_method_ref)->reference_index, runtime);
    if (!boot_m) {
        ConstantMethodRef *cmr = class_get_constant_method_ref(clazz, class_get_method_handle(clazz, bootMethod->bootstrap_method_ref)->reference_index);
        _nosuchmethod_check_exception(utf8_cstr(cmr->name), stack, runtime);
        return RUNTIME_STATUS_EXCEPTION;
    } else {
        s32 ret = execute_method_impl(boot_m, runtime);
        if (ret == RUNTIME_STATUS_NORMAL) {
            MethodInfo *finder = find_methodInfo_by_name_c("org/mini/vm/LambdaUtil",
                                                           "getMethodInfoHandle",
                                                           "(Ljava/lang/invoke/CallSite;)J", NULL,
                                                           runtime);
            if (!finder) {
                _nosuchmethod_check_exception("getMethodInfoHandle", stack, runtime);
                return RUNTIME_STATUS_EXCEPTION;
            } else {
                //run finder to convert calsite.target(MethodHandle) to MethodInfo * pointer
                ret = execute_method_impl(finder, runtime);
                if (ret == RUNTIME_STATUS_NORMAL) {
                    MethodInfo *make = (MethodInfo *) (intptr_t) pop_long(stack);
                    bootMethod->make = make;
                }
            }
        } else {
            return ret;
        }
    }
    return RUNTIME_STATUS_NORMAL;
}

s32 checkcast(Runtime *runtime, Instance *ins, s32 typeIdx) {
    JClass *clazz = runtime->clazz;
    if (ins != NULL) {
        if (ins->mb.type == MEM_TYPE_INS) {
            JClass *other = getClassByConstantClassRef(clazz, typeIdx, runtime);
            if (instance_of(ins, other)) {
                return 1;
            }
        } else if (ins->mb.type == MEM_TYPE_ARR) {
            JClass *other = getClassByConstantClassRef(clazz, typeIdx, runtime);
            if (other && instance_of(ins, other)) {
                return 1;
            }
        } else if (ins->mb.type == MEM_TYPE_CLASS) {
            Utf8String *utf = class_get_constant_classref(clazz, typeIdx)->name;
            if (utf8_equals_c(utf, STR_CLASS_JAVA_LANG_CLASS)) {
                return 1;
            }
        }
    } else {
        return 1;
    }
    return 0;
}

/**
 * Store the method call parameters from the stack into the method's local variables.
 * Before calling a method, the parent program pushes the function parameters onto the stack.
 * When the method is called, the parameters from the stack need to be stored in the local variables.
 * @param method  Method being called
 * @param father  Runtime of the parent
 * @param son     Runtime of the child
 */
static inline s32 _synchronized_lock_method(MethodInfo *method, Runtime *runtime) {
    //synchronized process
    runtime->lock = NULL;
    if (!jdwp_is_ignore_sync(runtime->jvm->jdwpserver, runtime)) {
        if (method->is_static) {
            runtime->lock = (MemoryBlock *) runtime->clazz;
        } else {
            runtime->lock = (MemoryBlock *) localvar_getRefer(runtime->localvar, 0);
        }
        if (jthread_lock(runtime->lock, runtime) != 0) {
            runtime->lock = NULL;
            return RUNTIME_STATUS_ERROR;
        }
    }
    return RUNTIME_STATUS_NORMAL;
}

static inline void _synchronized_unlock_method(MethodInfo *method, Runtime *runtime) {
    //synchronized process
    if (runtime->lock) {
        jthread_unlock(runtime->lock, runtime);
        runtime->lock = NULL;
    }
}

/**
 *    only static and special can be optimize , invokevirtual and invokeinterface may called by diff instance
 * @param subm
 * @param parent_method_code
 */
static inline void _optimize_empty_method_call(MethodInfo *subm, CodeAttribute *parent_ca, u8 *parent_method_code) {
    CodeAttribute *ca = subm->converted_code;
    u8 *parent_jit_code = &parent_ca->bytecode_for_jit[parent_method_code - parent_ca->code];
    if (ca && ca->code_length == 1 && *ca->code == op_return) {
        //empty method, do nothing
        s32 paras = subm->para_slots; //

        if (paras == 0) {
            *parent_method_code = op_nop;
            *(parent_method_code + 1) = op_nop;
            *(parent_method_code + 2) = op_nop;

            *parent_jit_code = op_nop;
            *(parent_jit_code + 1) = op_nop;
            *(parent_jit_code + 2) = op_nop;
        } else if (paras == 1) {
            *parent_method_code = op_pop;
            *(parent_method_code + 1) = op_nop;
            *(parent_method_code + 2) = op_nop;

            *parent_jit_code = op_pop;
            *(parent_jit_code + 1) = op_nop;
            *(parent_jit_code + 2) = op_nop;
        } else if (paras == 2) {
            *parent_method_code = op_pop2;
            *(parent_method_code + 1) = op_nop;
            *(parent_method_code + 2) = op_nop;

            *parent_jit_code = op_pop2;
            *(parent_jit_code + 1) = op_nop;
            *(parent_jit_code + 2) = op_nop;
        }
    }
}


static inline s32 _optimize_inline_getter(JClass *clazz, s32 cfrIdx, Runtime *runtime) {
    RuntimeStack *stack = runtime->stack;
    FieldInfo *fi = class_get_constant_fieldref(clazz, cfrIdx)->fieldInfo;
    if (!fi) {
        ConstantFieldRef *cfr = class_get_constant_fieldref(clazz, cfrIdx);
        fi = find_fieldInfo_by_fieldref(clazz, cfr->item.index, runtime);
        cfr->fieldInfo = fi;
        if (!fi) {
            _nosuchfield_check_exception(utf8_cstr(cfr->name), runtime->stack, runtime);
            return RUNTIME_STATUS_EXCEPTION;
        }
    }
    Instance *fins = pop_ref(stack);
    if (!fins) {
        _null_throw_exception(stack, runtime);
        return RUNTIME_STATUS_EXCEPTION;
    }
    if (fi->_this_class->status < CLASS_STATUS_CLINITED) {
        class_clinit(fi->_this_class, runtime);
    }
    if (fi->isrefer) {
        push_ref(stack, *((__refer *) (getInstanceFieldPtr(fins, fi))));
    } else {
        // check variable type to determine s64/s32/f64/f32
        s32 data_bytes = fi->datatype_bytes;
        switch (data_bytes) {
            case 4: {
                push_int(stack, *((s32 *) (getInstanceFieldPtr(fins, fi))));
                break;
            }
            case 1: {
                push_int(stack, *((s8 *) (getInstanceFieldPtr(fins, fi))));
                break;
            }
            case 8: {
                push_long(stack, *((s64 *) (getInstanceFieldPtr(fins, fi))));
                break;
            }
            case 2: {
                if (fi->datatype_idx == DATATYPE_JCHAR) {
                    push_int(stack, *((u16 *) (getInstanceFieldPtr(fins, fi))));
                } else {
                    push_int(stack, *((s16 *) (getInstanceFieldPtr(fins, fi))));
                }
                break;
            }
            default: {
                break;
            }
        }
    }
    return RUNTIME_STATUS_NORMAL;
}

static inline s32 _optimize_inline_setter(JClass *clazz, s32 cfrIdx, Runtime *runtime) {
    RuntimeStack *stack = runtime->stack;
    FieldInfo *fi = class_get_constant_fieldref(clazz, cfrIdx)->fieldInfo;
    if (!fi) {
        ConstantFieldRef *cfr = class_get_constant_fieldref(clazz, cfrIdx);
        fi = find_fieldInfo_by_fieldref(clazz, cfr->item.index, runtime);
        cfr->fieldInfo = fi;
        if (!fi) {
            _nosuchfield_check_exception(utf8_cstr(cfr->name), runtime->stack, runtime);
            return RUNTIME_STATUS_EXCEPTION;
        }
    }

    if (fi->_this_class->status < CLASS_STATUS_CLINITED) {
        class_clinit(fi->_this_class, runtime);
    }
    if (fi->isrefer) {
        __refer v = pop_ref(stack);
        Instance *fins = pop_ref(stack);
        if (!fins) {
            _null_throw_exception(stack, runtime);
            return RUNTIME_STATUS_EXCEPTION;
        }
        *((__refer *) (getInstanceFieldPtr(fins, fi))) = v;
    } else {
        // check variable type to determine s64/s32/f64/f32
        s32 data_bytes = fi->datatype_bytes;
        switch (data_bytes) {
            case 4: {
                s32 v = pop_int(stack);
                Instance *fins = pop_ref(stack);
                if (!fins) {
                    _null_throw_exception(stack, runtime);
                    return RUNTIME_STATUS_EXCEPTION;
                }
                *((s32 *) (getInstanceFieldPtr(fins, fi))) = v;
                break;
            }
            case 1: {
                s32 v = pop_int(stack);
                Instance *fins = pop_ref(stack);
                if (!fins) {
                    _null_throw_exception(stack, runtime);
                    return RUNTIME_STATUS_EXCEPTION;
                }
                *((s8 *) (getInstanceFieldPtr(fins, fi))) = v;
                break;
            }
            case 8: {
                s64 v = pop_long(stack);
                Instance *fins = pop_ref(stack);
                if (!fins) {
                    _null_throw_exception(stack, runtime);
                    return RUNTIME_STATUS_EXCEPTION;
                }
                *((s64 *) (getInstanceFieldPtr(fins, fi))) = v;
                break;
            }
            case 2: {
                s32 v = pop_int(stack);
                Instance *fins = pop_ref(stack);
                if (!fins) {
                    _null_throw_exception(stack, runtime);
                    return RUNTIME_STATUS_EXCEPTION;
                }
                *((u16 *) (getInstanceFieldPtr(fins, fi))) = v;
                break;
            }
            default: {
                break;
            }
        }
    }
    return RUNTIME_STATUS_NORMAL;
}


/* Shared result handling for one compiled-code call.  Since the calling
 * convention unification, a compiled java body and a resolved JNI native
 * are the same callable shape (Runtime*, JClass*), so this tail is common:
 *  - EXCEPTION: normalize the reference to base+1.  A native leaves it at
 *    the call boundary; a compiled body already did this in its own
 *    exception path and the pop/dispose/push is idempotent for that state.
 *  - NORMAL: shape the result from (sp - return_slots), exactly like the
 *    interpreted return opcodes.
 *  - ERROR / INTERRUPT carry no reference and must not touch the stack. */
static s32 _finish_compiled_call(MethodInfo *method, Runtime *r, s32 ret) {
    if (ret == RUNTIME_STATUS_EXCEPTION) {
        r->ins = pop_ref(r->stack);
        localvar_dispose(r);
        push_ref(r->stack, r->ins);
    } else if (ret == RUNTIME_STATUS_NORMAL) {
        switch (method->return_slots) {
            case 0: {
                // V
                localvar_dispose(r);
                break;
            }
            case 1: {
                // F I R
                peek_entry(r->stack->sp - method->return_slots, &r->entry);
                localvar_dispose(r);
                push_entry(r->stack, &r->entry);
                break;
            }
            case 2: {
                //J D return type , 2slots
                r->lval1 = pop_long(r->stack);
                localvar_dispose(r);
                push_long(r->stack, r->lval1);
                break;
            }
            default: {
                break;
            }
        }
    }
    return ret;
}

s32 execute_method_impl(MethodInfo *method, Runtime *pruntime) {
#if _JVM_DEBUG_METHOD_PROFILE || _JVM_DEBUG_SLOW_CALL_PROFILE
    s64 start_time = nanoTime();
#endif
    //local var for control
    s32 ret;
    Runtime *r;
    RuntimeStack *stack;
    LocalVarItem *localvar;
    JClass *clazz;
    //register u8 *r->pc;
    register StackEntry *sp;

    //start
    ret = RUNTIME_STATUS_NORMAL;
    r = runtime_create_inl(pruntime);
#if _JVM_DEBUG_SLOW_CALL_PROFILE
    r->slow_profile_start_at = start_time;
    r->slow_profile_child_spent = 0;
    if (r->jvm && r->jvm->collector) {
        r->slow_profile_gc_pause_at_enter = ATOMIC_ADD64(&r->jvm->collector->stw_total_ns, 0);
    } else {
        r->slow_profile_gc_pause_at_enter = 0;
    }
#endif

    clazz = method->_this_class;
    r->clazz = clazz;
    r->method = method;
#if _JVM_DEBUG_SLOW_CALL_PROFILE
    profile_slow_call_enter(r, method, start_time);
#endif
    while (clazz->status < CLASS_STATUS_CLINITING) {
        class_clinit(clazz, r);
    }
#if _JVM_DEBUG_LOG_LEVEL > 3
    invoke_deepth(pruntime);
    jvm_printf("%s.%s%s { //\n", utf8_cstr(method->_this_class->name),
               utf8_cstr(method->name), utf8_cstr(method->descriptor));
#endif

    //    if (utf8_equals_c(method->name, "<clinit>")
    //        && utf8_equals_c(clazz->name, "org/mini/g3d/core/gltf2/loader/GLTFJsonModule")
    //            ) {
    //        s32 debug = 1;
    //    }

    stack = r->stack;

    if (!(method->is_native)) {
        CodeAttribute *ca = method->converted_code;
        if (ca) {
            /* full frame need: caller SP + locals reserve + callee max_stack.
             * localvar_init below raises sp by max(max_locals, para_slots) - para_slots,
             * so the reserve must be part of the bound or deep frames can overrun. */
            s32 local_reserve = ca->max_locals > method->para_slots ? ca->max_locals - method->para_slots : 0;
            if (stack->max_size < (stack->sp - stack->store) + local_reserve + ca->max_stack) {
                jvm_printf("Stack overflow :\n");
                print_runtime_stack(r);
                exit(1);
            }
            r->pc = ca->code;

            localvar_init(r, ca->max_locals, method->para_slots);

            //method sync begin
            if (method->is_sync && _synchronized_lock_method(method, r) != RUNTIME_STATUS_NORMAL) {
                ret = RUNTIME_STATUS_ERROR;
                goto label_exit_while;
            }

            if (r->thrd_info->is_stop) {
                //if stop=1 then exit thread
                ret = RUNTIME_STATUS_ERROR;
                goto label_exit_while;
            }

            if (JIT_ENABLE && ca->jit.state == JIT_GEN_SUCCESS) {
                // compiled java body: same callable shape as a native
                ret = ca->jit.func(r, clazz);
                if (ret != RUNTIME_STATUS_ERROR) {
                    ret = _finish_compiled_call(method, r, ret);
                }
            } else {
                if (JIT_ENABLE && ca->jit.state == JIT_GEN_UNKNOW) {
                    if (ca->jit.interpreted_count++ > JIT_COMPILE_EXEC_COUNT) {
                        spin_lock(&ca->compile_lock);
                        if (ca->jit.state == JIT_GEN_UNKNOW) {
                            //re test
                            //jvm_printf("enter jit %s.%s()\n", utf8_cstr(method->_this_class->name), utf8_cstr(method->name));
                            construct_jit(method, r);
                        }
                        spin_unlock(&ca->compile_lock);
                    }
                }

                localvar = r->localvar;
                sp = r->stack->sp;

                do {
                    if (r->jvm->jdwp_enable && jdwp_client_count(r->jvm->jdwpserver)) {
                        stack->sp = sp;

                        if (!r->thrd_info->no_pause) {
                            //breakpoint
                            if (method->breakpoint) {
                                jdwp_check_breakpoint(r);
                            }
                            //debug step
                            if (r->thrd_info->jdwp_step->active) {
                                //单步状态
                                r->thrd_info->jdwp_step->bytecode_count++;
                                jdwp_check_debug_step(r);
                            }
                        }
                        sp = stack->sp;
                        check_gc_pause(-1); //step debug required
                    }
#if _JVM_DEBUG_LOG_LEVEL > 1
                    if (r->jvm->collector->isworldstoped && r->thrd_info->top_runtime != r->jvm->collector->runtime) {
                        jvm_printf("[ERROR] world stopped, but thread is running: %llx\n", (s64) (intptr_t) r->thrd_info->jthread);
                    }
#endif   //_JVM_DEBUG_LOG_LEVEL > 1


#if _JVM_DEBUG_BYTECODE_PROFILE
                    u8 cur_inst = *r->pc;
                    s64 spent = 0;
                    s64 start_at = nanoTime();
#endif

                    /* ======================================================opcode start=================================================*/
#ifdef __JVM_DEBUG__
                    s64 inst_pc = r->pc - ca->code;
#endif
                    switch (*r->pc) {
                        case op_nop: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("nop\n");
#endif
                            r->pc++;

                            break;
                        }

                        case op_aconst_null: {
                            (sp++)->rvalue = NULL;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("aconst_null: push %d into stack\n", 0);
#endif
                            r->pc++;

                            break;
                        }

                        case op_iconst_m1: {
                            (sp++)->ivalue = -1;
                            r->pc++;
                            break;
                        }


                        case op_iconst_0: {
                            (sp++)->ivalue = 0;
                            r->pc++;
                            break;
                        }


                        case op_iconst_1: {
                            (sp++)->ivalue = 1;
                            r->pc++;
                            break;
                        }


                        case op_iconst_2: {
                            (sp++)->ivalue = 2;
                            r->pc++;
                            break;
                        }


                        case op_iconst_3: {
                            (sp++)->ivalue = 3;
                            r->pc++;
                            break;
                        }


                        case op_iconst_4: {
                            (sp++)->ivalue = 4;
                            r->pc++;
                            break;
                        }


                        case op_iconst_5: {
                            (sp++)->ivalue = 5;
                            r->pc++;
                            break;
                        }


                        case op_lconst_0: {
                            (sp++)->lvalue = 0;
                            sp++;
                            r->pc++;
                            break;
                        }


                        case op_lconst_1: {
                            (sp++)->lvalue = 1;
                            sp++;
                            r->pc++;
                            break;
                        }


                        case op_fconst_0: {
                            (sp++)->fvalue = 0;
                            r->pc++;
                            break;
                        }


                        case op_fconst_1: {
                            (sp++)->fvalue = 1;
                            r->pc++;
                            break;
                        }


                        case op_fconst_2: {
                            (sp++)->fvalue = 2;
                            r->pc++;
                            break;
                        }


                        case op_dconst_0: {
                            (sp++)->dvalue = 0;
                            sp++;
                            r->pc++;
                            break;
                        }


                        case op_dconst_1: {
                            (sp++)->dvalue = 1;
                            sp++;
                            r->pc++;
                            break;
                        }


                        case op_bipush: {
                            (sp++)->ivalue = (s8) r->pc[1];
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("bipush a byte %d onto the stack \n", (sp - 1)->ivalue);
#endif
                            r->pc += 2;

                            break;
                        }


                        case op_sipush: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("sipush value %d\n", *((s16 *) (r->pc + 1)));
#endif
                            (sp++)->ivalue = *((s16 *) (r->pc + 1));
                            r->pc += 3;

                            break;
                        }

                        case op_ldc:
                        case op_ldc_w: {
                            if (*r->pc == op_ldc) {
                                r->idx = r->pc[1];
                                r->pc += 2;
                            } else {
                                r->idx = *((u16 *) (r->pc + 1));
                                r->pc += 3;
                            }
                            ConstantItem *item = class_get_constant_item(clazz, r->idx);
                            switch (item->tag) {
                                case CONSTANT_INTEGER:
                                case CONSTANT_FLOAT: {
                                    r->ival1 = class_get_constant_integer(clazz, r->idx);
                                    (sp++)->ivalue = r->ival1;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                    invoke_deepth(r);
                                    jvm_printf("ldc: [%x] \n", r->ival1);
#endif
                                    break;
                                }
                                case CONSTANT_STRING_REF: {
                                    ConstantUTF8 *cutf = class_get_constant_utf8(clazz, class_get_constant_stringref(clazz, r->idx)->stringIndex);
                                    (sp++)->rvalue = cutf->jstr;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                    invoke_deepth(r);
                                    jvm_printf("ldc: [%llx] =\"%s\"\n", (s64) (intptr_t) cutf->jstr, utf8_cstr(cutf->utfstr));
#endif
                                    break;
                                }
                                case CONSTANT_CLASS: {
                                    stack->sp = sp;
                                    r->other = classes_load_get_with_clinit(clazz->jloader, class_get_constant_classref(clazz, r->idx)->name, r);
                                    if (!r->other->ins_class) {
                                        r->other->ins_class = insOfJavaLangClass_create_get(r, r->other);
                                    }
                                    sp = stack->sp;
                                    (sp++)->rvalue = r->other->ins_class;
                                    break;
                                }
                                default: {
                                    jvm_printf("ldc: something not implemention \n");
                                }
                            }
                            break;
                        }


                        case op_ldc2_w: {
                            r->lval1 = class_get_constant_long(clazz, *((u16 *) (r->pc + 1))); //long or double
                            (sp++)->lvalue = r->lval1;
                            sp++;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ldc2_w: push a constant(%d) [%llx] onto the stack \n", *((u16 *) (r->pc + 1)), (sp - 2)->lvalue);
#endif
                            r->pc += 3;

                            break;
                        }


                        case op_iload:
                        case op_fload: {
                            (sp++)->ivalue = localvar[(u8) r->pc[1]].ivalue;
                            r->pc += 2;
                            break;
                        }

                        case op_aload: {
                            (sp++)->rvalue = localvar[(u8) r->pc[1]].rvalue;
                            r->pc += 2;
                            break;
                        }


                        case op_lload:
                        case op_dload: {
                            (sp++)->lvalue = localvar[(u8) r->pc[1]].lvalue;
                            sp++;
                            r->pc += 2;
                            break;
                        }

                        case op_fload_0:
                        case op_iload_0: {
                            (sp++)->ivalue = localvar[0].ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fload_1:
                        case op_iload_1: {
                            (sp++)->ivalue = localvar[1].ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fload_2:
                        case op_iload_2: {
                            (sp++)->ivalue = localvar[2].ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fload_3:
                        case op_iload_3: {
                            (sp++)->ivalue = localvar[3].ivalue;
                            r->pc++;
                            break;
                        }

                        case op_dload_0:
                        case op_lload_0: {
                            (sp++)->lvalue = localvar[0].lvalue;
                            (sp++);
                            r->pc++;
                            break;
                        }

                        case op_dload_1:
                        case op_lload_1: {
                            (sp++)->lvalue = localvar[1].lvalue;
                            (sp++);
                            r->pc++;
                            break;
                        }

                        case op_dload_2:
                        case op_lload_2: {
                            (sp++)->lvalue = localvar[2].lvalue;
                            (sp++);
                            r->pc++;
                            break;
                        }

                        case op_dload_3:
                        case op_lload_3: {
                            (sp++)->lvalue = localvar[3].lvalue;
                            (sp++);
                            r->pc++;
                            break;
                        }

                        case op_aload_0: {
                            (sp++)->rvalue = localvar[0].rvalue;
                            r->pc++;
                            break;
                        }


                        case op_aload_1: {
                            (sp++)->rvalue = localvar[1].rvalue;
                            r->pc++;
                            break;
                        }


                        case op_aload_2: {
                            (sp++)->rvalue = localvar[2].rvalue;
                            r->pc++;
                            break;
                        }


                        case op_aload_3: {
                            (sp++)->rvalue = localvar[3].rvalue;
                            r->pc++;
                            break;
                        }


                        case op_iaload:
                        case op_faload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->ival1 = *((s32 *) (jarray_body(r->ins)) + r->idx);
                                (sp++)->ivalue = r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("if_aload push arr[%llx].(%d)=%x:%d:%lf into stack\n", (u64) (intptr_t) r->ins, r->idx, r->ival1, r->ival1, *(f32 *) &r->ival1);
#endif
                                r->pc++;
                            }
                            break;
                        }


                        case op_laload:
                        case op_daload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->lval1 = *(((s64 *) jarray_body(r->ins)) + r->idx);
                                (sp++)->lvalue = r->lval1;
                                (sp++);
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("ld_aload push arr[%llx].(%d)=%llx:%lld:%lf into stack\n", (u64) (intptr_t) r->ins, r->idx, r->lval1, r->lval1, *(f64 *) &r->lval1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_aaload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->rval1 = *(((__refer *) jarray_body(r->ins)) + r->idx);
                                (sp++)->rvalue = r->rval1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("aaload push arr[%llx].(%d)=%llx:%lld into stack\n", (u64) (intptr_t) r->ins, r->idx, (s64) (intptr_t) r->rval1, (s64) (intptr_t) r->rval1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_baload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->ival1 = *(((s8 *) jarray_body(r->ins)) + r->idx);
                                (sp++)->ivalue = r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iaload push arr[%llx].(%d)=%x:%d:%lf into stack\n", (u64) (intptr_t) r->ins, r->idx, r->ival1, r->ival1, *(f32 *) &r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_caload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->ival1 = *(((u16 *) jarray_body(r->ins)) + r->idx);
                                (sp++)->ivalue = r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iaload push arr[%llx].(%d)=%x:%d:%lf into stack\n", (u64) (intptr_t) r->ins, r->idx, r->ival1, r->ival1, *(f32 *) &r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_saload: {
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                r->ival1 = *(((s16 *) jarray_body(r->ins)) + r->idx);
                                (sp++)->ivalue = r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iaload push arr[%llx].(%d)=%x:%d:%lf into stack\n", (u64) (intptr_t) r->ins, r->idx, r->ival1, r->ival1, *(f32 *) &r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_istore:
                        case op_fstore: {
                            localvar[(u8) r->pc[1]].ivalue = (--sp)->ivalue;
                            r->pc += 2;
                            break;
                        }

                        case op_astore: {
                            localvar[(u8) r->pc[1]].rvalue = (--sp)->rvalue;
                            r->pc += 2;
                            break;
                        }


                        case op_lstore:
                        case op_dstore: {
                            --sp;
                            --sp;
                            localvar[(u8) r->pc[1]].lvalue = (sp)->lvalue;
                            r->pc += 2;

                            break;
                        }

                        case op_fstore_0:
                        case op_istore_0: {
                            localvar[0].ivalue = (--sp)->ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fstore_1:
                        case op_istore_1: {
                            localvar[1].ivalue = (--sp)->ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fstore_2:
                        case op_istore_2: {
                            localvar[2].ivalue = (--sp)->ivalue;
                            r->pc++;
                            break;
                        }

                        case op_fstore_3:
                        case op_istore_3: {
                            localvar[3].ivalue = (--sp)->ivalue;
                            r->pc++;
                            break;
                        }

                        case op_dstore_0:
                        case op_lstore_0: {
                            --sp;
                            localvar[0].lvalue = (--sp)->lvalue;
                            r->pc++;
                            break;
                        }

                        case op_dstore_1:
                        case op_lstore_1: {
                            --sp;
                            localvar[1].lvalue = (--sp)->lvalue;
                            r->pc++;
                            break;
                        }

                        case op_dstore_2:
                        case op_lstore_2: {
                            --sp;
                            localvar[2].lvalue = (--sp)->lvalue;
                            r->pc++;
                            break;
                        }

                        case op_dstore_3:
                        case op_lstore_3: {
                            --sp;
                            localvar[3].lvalue = (--sp)->lvalue;
                            r->pc++;
                            break;
                        }

                        case op_astore_0: {
                            localvar[0].rvalue = (--sp)->rvalue;
                            r->pc++;
                            break;
                        }


                        case op_astore_1: {
                            localvar[1].rvalue = (--sp)->rvalue;
                            r->pc++;
                            break;
                        }


                        case op_astore_2: {
                            localvar[2].rvalue = (--sp)->rvalue;
                            r->pc++;
                            break;
                        }


                        case op_astore_3: {
                            localvar[3].rvalue = (--sp)->rvalue;
                            r->pc++;
                            break;
                        }


                        case op_fastore:
                        case op_iastore: {
                            r->ival1 = (--sp)->ivalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                *(((s32 *) jarray_body(r->ins)) + r->idx) = r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%d)\n", (s64) (intptr_t) r->ins, r->idx, r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_dastore:
                        case op_lastore: {
                            --sp;
                            r->lval1 = (--sp)->lvalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                *(((s64 *) jarray_body(r->ins)) + r->idx) = r->lval1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%lld)\n", (s64) (intptr_t) r->ins, r->idx, r->lval1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_aastore: {
                            r->rval1 = (--sp)->rvalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else if (!jarray_reference_store_check(r->ins, r->rval1)) {
                                goto label_arraystore_throw;
                            } else {
                                *(((__refer *) jarray_body(r->ins)) + r->idx) = r->rval1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%llx)\n", (s64) (intptr_t) r->ins, r->idx, (s64) (intptr_t) r->rval1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_bastore: {
                            r->ival1 = (--sp)->ivalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                *(((s8 *) jarray_body(r->ins)) + r->idx) = (s8) r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%d)\n", (s64) (intptr_t) r->ins, r->idx, r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_castore: {
                            r->ival1 = (--sp)->ivalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                *(((u16 *) jarray_body(r->ins)) + r->idx) = (u16) r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%d)\n", (s64) (intptr_t) r->ins, r->idx, r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_sastore: {
                            r->ival1 = (--sp)->ivalue;
                            r->idx = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else if (r->idx < 0 || r->idx >= jarray_length(r->ins)) {
                                goto label_outofbounds_throw;
                            } else {
                                *(((s16 *) jarray_body(r->ins)) + r->idx) = (s16) r->ival1;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("iastore: save array[%llx].(%d)=%d)\n", (s64) (intptr_t) r->ins, r->idx, r->ival1);
#endif

                                r->pc++;
                            }
                            break;
                        }


                        case op_pop: {
                            --sp;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("pop\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_pop2: {
                            --sp;
                            --sp;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("pop2\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup: {
                            *(sp - 0) = *(sp - 1);
                            sp++;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup_x1: {
                            *(sp - 0) = *(sp - 1);
                            *(sp - 1) = *(sp - 2);
                            *(sp - 2) = *(sp - 0);
                            sp++;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup_x1\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup_x2: {
                            *(sp - 0) = *(sp - 1);
                            *(sp - 1) = *(sp - 2);
                            *(sp - 2) = *(sp - 3);
                            *(sp - 3) = *(sp - 0);
                            sp++;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup_x2 \n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup2: {
                            *(sp - 0) = *(sp - 2);
                            *(sp + 1) = *(sp - 1);
                            sp++;
                            sp++;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup2\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup2_x1: {
                            sp++;
                            sp++;
                            *(sp - 1) = *(sp - 3);
                            *(sp - 2) = *(sp - 4);
                            *(sp - 3) = *(sp - 5);
                            *(sp - 5) = *(sp - 2);
                            *(sp - 4) = *(sp - 1);


#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup2_x1\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_dup2_x2: {
                            sp++;
                            sp++;
                            *(sp - 1) = *(sp - 3);
                            *(sp - 2) = *(sp - 4);
                            *(sp - 3) = *(sp - 5);
                            *(sp - 4) = *(sp - 6);
                            *(sp - 6) = *(sp - 2);
                            *(sp - 5) = *(sp - 1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dup2_x2\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_swap: {
                            *(sp - 0) = *(sp - 2);
                            *(sp - 2) = *(sp - 1);
                            *(sp - 1) = *(sp - 0);


#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("swap\n");
#endif
                            r->pc++;

                            break;
                        }


                        case op_iadd: {
                            --sp;
                            (sp - 1)->ivalue += (sp - 0)->ivalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("iadd:  %d\n", (sp - 1)->ivalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_ladd: {
                            --sp;
                            --sp;
                            (sp - 2)->lvalue += (sp - 0)->lvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ladd:  %lld\n", (sp - 2)->lvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_fadd: {
                            --sp;
                            (sp - 1)->fvalue += (sp - 0)->fvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("fadd:  %f\n", (sp - 1)->fvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_dadd: {
                            --sp;
                            --sp;
                            (sp - 2)->dvalue += (sp - 0)->dvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dadd:  %lf\n", (sp - 2)->dvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_isub: {
                            --sp;
                            (sp - 1)->ivalue -= (sp - 0)->ivalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("isub :  %d\n", (sp - 1)->ivalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_lsub: {
                            --sp;
                            --sp;
                            (sp - 2)->lvalue -= (sp - 0)->lvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lsub:  %lld\n", (sp - 2)->lvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_fsub: {
                            --sp;
                            (sp - 1)->fvalue -= (sp - 0)->fvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("fsub:  %f\n", (sp - 1)->fvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_dsub: {
                            --sp;
                            --sp;
                            (sp - 2)->dvalue -= (sp - 0)->dvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dsub:  %lf\n", (sp - 2)->dvalue);
#endif

                            r->pc++;

                            break;
                        }


                        case op_imul: {
                            --sp;
                            (sp - 1)->ivalue *= (sp - 0)->ivalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("imul:  %d\n", (sp - 1)->ivalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_lmul: {
                            --sp;
                            --sp;
                            (sp - 2)->lvalue *= (sp - 0)->lvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lmul:  %lld\n", (sp - 2)->lvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_fmul: {
                            --sp;
                            (sp - 1)->fvalue *= (sp - 0)->fvalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("fmul:  %f\n", (sp - 1)->fvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_dmul: {
                            --sp;
                            --sp;
                            (sp - 2)->dvalue *= (sp - 0)->dvalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dmul:  %lf\n", (sp - 2)->dvalue);
#endif
                            r->pc++;

                            break;
                        }


                        case op_idiv: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("idiv:  %d\n", (sp - 1)->ivalue);
#endif
                            if (!(sp - 1)->ivalue) {
                                goto label_arrithmetic_throw;
                            } else {
                                --sp;
                                (sp - 1)->ivalue /= (sp - 0)->ivalue;
                                r->pc++;
                            }

                            break;
                        }


                        case op_ldiv: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ldiv:  %lld\n", (sp - 2)->lvalue);
#endif
                            if (!(sp - 2)->lvalue) {
                                goto label_arrithmetic_throw;
                            } else {
                                --sp;
                                --sp;
                                (sp - 2)->lvalue /= (sp - 0)->lvalue;
                                r->pc++;
                            }

                            break;
                        }


                        case op_fdiv: {
                            // there isn't r exception throw
                            // https://github.com/digitalgust/miniJVM/issues/30
                            --sp;
                            (sp - 1)->fvalue /= (sp - 0)->fvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("fdiv:  %f\n", (sp - 1)->fvalue);
#endif
                            r->pc++;
                            break;
                        }

                        case op_ddiv: {
                            // there isn't r exception throw
                            // https://github.com/digitalgust/miniJVM/issues/30
                            --sp;
                            --sp;
                            (sp - 2)->dvalue /= (sp - 0)->dvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ddiv:  %lf\n", (sp - 2)->dvalue);
#endif
                            r->pc++;
                            break;
                        }


                        case op_irem: {
                            if (!(sp - 1)->ivalue) {
                                goto label_arrithmetic_throw;
                            } else {
                                --sp;
                                (sp - 1)->ivalue %= (sp - 0)->ivalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("irem:  %d\n", (sp - 1)->ivalue);
#endif
                                r->pc++;
                            }
                            break;
                        }


                        case op_lrem: {
                            if (!(sp - 2)->lvalue) {
                                goto label_arrithmetic_throw;
                            } else {
                                --sp;
                                --sp;
                                (sp - 2)->lvalue %= (sp - 0)->lvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("lrem:  %lld\n", (sp - 2)->lvalue);
#endif
                                r->pc++;
                            }
                            break;
                        }


                        case op_frem: {
                            // there isn't r exception throw
                            // https://github.com/digitalgust/miniJVM/issues/30
                            --sp;
                            r->fval1 = (sp - 0)->fvalue;
                            r->fval2 = (sp - 1)->fvalue;
                            f32 v = r->fval2 - ((s32) (r->fval2 / r->fval1) * r->fval1);
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("frem:  %f\n", (sp - 1)->fvalue);
#endif
                            (sp - 1)->fvalue = v;
                            r->pc++;
                            break;
                        }


                        case op_drem: {
                            // there isn't r exception throw
                            // https://github.com/digitalgust/miniJVM/issues/30
                            --sp;
                            --sp;
                            r->dval1 = (sp - 0)->dvalue;
                            r->dval2 = (sp - 2)->dvalue;
                            f64 v = r->dval2 - ((s64) (r->dval2 / r->dval1) * r->dval1);;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("drem:  %lf\n", (sp - 2)->dvalue);
#endif
                            (sp - 2)->dvalue = v;
                            r->pc++;
                            break;
                        }


                        case op_ineg: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ineg:  %d\n", (sp - 1)->ivalue);
#endif
                            (sp - 1)->ivalue = -(sp - 1)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lneg: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lneg:  %lld\n", (sp - 2)->lvalue);
#endif
                            (sp - 2)->lvalue = -(sp - 2)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_fneg: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("fneg:  %f\n", (sp - 1)->fvalue);
#endif
                            (sp - 1)->fvalue = -(sp - 1)->fvalue;
                            r->pc++;

                            break;
                        }


                        case op_dneg: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("dneg:  %lf\n", (sp - 2)->dvalue);
#endif
                            (sp - 2)->dvalue = -(sp - 2)->dvalue;
                            r->pc++;

                            break;
                        }


                        case op_ishl: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ishl: %x << %x  \n", (sp - 2)->ivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->ivalue <<= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lshl: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lshl: %llx << %x  \n", (sp - 3)->lvalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 2)->lvalue <<= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_ishr: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ishr: %x >> %x  \n", (sp - 2)->ivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->ivalue >>= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lshr: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lshr: %llx >> %x  \n", (sp - 3)->lvalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 2)->lvalue >>= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_iushr: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("iushr: %x >>> %x  \n", (sp - 2)->uivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->uivalue >>= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lushr: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lushr: %llx >>> %x   \n", (sp - 3)->ulvalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 2)->ulvalue >>= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_iand: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("iand: %x & %x  \n", (sp - 2)->ivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->ivalue &= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_land: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("land: %llx  &  %llx  \n", (sp - 4)->lvalue, (sp - 2)->lvalue);
#endif
                            --sp;
                            --sp;
                            (sp - 2)->lvalue &= (sp - 0)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_ior: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ior: %x & %x  \n", (sp - 2)->ivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->ivalue |= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lor: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lor: %llx  |  %llx   \n", (sp - 4)->lvalue, (sp - 2)->lvalue);
#endif
                            --sp;
                            --sp;
                            (sp - 2)->lvalue |= (sp - 0)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_ixor: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ixor: %x ^ %x  \n", (sp - 2)->ivalue, (sp - 1)->ivalue);
#endif
                            --sp;
                            (sp - 1)->ivalue ^= (sp - 0)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lxor: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lxor: %llx  ^  %llx  \n", (sp - 4)->lvalue, (sp - 2)->lvalue);
#endif
                            --sp;
                            --sp;
                            (sp - 2)->lvalue ^= (sp - 0)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_iinc: {
                            localvar[(u8) r->pc[1]].ivalue += (s8) r->pc[2];
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("iinc: localvar(%d) = %d , inc %d\n", (u8) r->pc[1], r->localvar[(u8) r->pc[1]].ivalue, (s8) r->pc[2]);
#endif

                            break;
                        }


                        case op_i2l: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2l:  %d\n", (sp - 1)->ivalue);
#endif
                            ++sp;
                            (sp - 2)->lvalue = (s64) (sp - 2)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_i2f: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2f:  %d\n", (sp - 1)->ivalue);
#endif
                            (sp - 1)->fvalue = (f32) (sp - 1)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_i2d: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2d:  %d\n", (sp - 1)->ivalue);
#endif
                            ++sp;
                            (sp - 2)->dvalue = (f64) (sp - 2)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_l2i: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("l2i:  %lld\n", (sp - 2)->lvalue);
#endif
                            --sp;
                            (sp - 1)->ivalue = (s32) (sp - 1)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_l2f: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("l2f:  %lld\n", (sp - 2)->lvalue);
#endif
                            --sp;
                            (sp - 1)->fvalue = (f32) (sp - 1)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_l2d: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("l2d:  %lld\n", (sp - 2)->lvalue);
#endif
                            (sp - 2)->dvalue = (f64) (sp - 2)->lvalue;
                            r->pc++;

                            break;
                        }


                        case op_f2i: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("f2i: %f\n", (sp - 1)->fvalue);
#endif
                            (sp - 1)->ivalue = jvm_float_to_int((sp - 1)->fvalue);
                            r->pc++;

                            break;
                        }


                        case op_f2l: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("f2l: %f\n", (sp - 1)->fvalue);
#endif
                            ++sp;
                            (sp - 2)->lvalue = jvm_float_to_long((sp - 2)->fvalue);
                            r->pc++;

                            break;
                        }


                        case op_f2d: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("f2d: %f\n", (sp - 1)->fvalue);
#endif
                            ++sp;
                            (sp - 2)->dvalue = (f64) (sp - 2)->fvalue;
                            r->pc++;

                            break;
                        }


                        case op_d2i: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("d2i: %lf\n", (sp - 2)->dvalue);
#endif
                            --sp;
                            (sp - 1)->ivalue = jvm_double_to_int((sp - 1)->dvalue);
                            r->pc++;

                            break;
                        }


                        case op_d2l: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("d2l: %lf\n", (sp - 2)->dvalue);
#endif
                            (sp - 2)->lvalue = jvm_double_to_long((sp - 2)->dvalue);
                            r->pc++;

                            break;
                        }


                        case op_d2f: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("d2f: %lf\n", (sp - 2)->dvalue);
#endif
                            --sp;
                            (sp - 1)->fvalue = (f32) (sp - 1)->dvalue;
                            r->pc++;

                            break;
                        }


                        case op_i2b: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2b:  %d\n", (sp - 1)->ivalue);
#endif
                            (sp - 1)->ivalue = (s8) (sp - 1)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_i2c: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2c:  %d\n", (sp - 1)->ivalue);
#endif
                            (sp - 1)->ivalue = (u16) (sp - 1)->ivalue;
                            r->pc++;

                            break;
                        }

                        case op_i2s: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("i2s:  %d\n", (sp - 1)->ivalue);
#endif
                            (sp - 1)->ivalue = (s16) (sp - 1)->ivalue;
                            r->pc++;

                            break;
                        }


                        case op_lcmp: {
                            --sp;
                            r->lval1 = (--sp)->lvalue;
                            --sp;
                            r->lval2 = (--sp)->lvalue;
                            s32 result = r->lval2 == r->lval1 ? 0 : (r->lval2 > r->lval1 ? 1 : -1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("lcmp: %llx cmp %llx = %d\n", r->lval2, r->lval1, result);
#endif
                            (sp++)->ivalue = result;

                            r->pc++;

                            break;
                        }


                        case op_fcmpl: {
                            r->fval1 = (--sp)->fvalue;
                            r->fval2 = (--sp)->fvalue;
                            if ((sp + 0)->uivalue == 0x7fc00000 || (sp + 1)->uivalue == 0x7fc00000) {
                                (sp++)->ivalue = -1;
                            } else {
                                s32 result = r->fval2 == r->fval1 ? 0 : (r->fval2 > r->fval1 ? 1 : -1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("fcmpl: %f < %f = %d\n", r->fval2, r->fval1, result);
#endif
                                (sp++)->ivalue = result;
                            }
                            r->pc++;

                            break;
                        }


                        case op_fcmpg: {
                            r->fval1 = (--sp)->fvalue;
                            r->fval2 = (--sp)->fvalue;
                            if ((sp + 0)->uivalue == 0x7fc00000 || (sp + 1)->uivalue == 0x7fc00000) {
                                (sp++)->ivalue = 1;
                            } else {
                                s32 result = r->fval2 == r->fval1 ? 0 : (r->fval2 > r->fval1 ? 1 : -1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("fcmpg: %f > %f = %d\n", r->fval2, r->fval1, result);
#endif
                                (sp++)->ivalue = result;
                            }
                            r->pc++;

                            break;
                        }


                        case op_dcmpl: {
                            --sp;
                            r->dval1 = (--sp)->dvalue;
                            --sp;
                            r->dval2 = (--sp)->dvalue;
                            if ((sp + 0)->ulvalue == 0x7ff8000000000000L || (sp + 2)->ulvalue == 0x7ff8000000000000L) {
                                (sp++)->ivalue = -1;
                            } else {
                                s32 result = r->dval2 == r->dval1 ? 0 : (r->dval2 > r->dval1 ? 1 : -1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("dcmpl: %lf < %lf = %d\n", r->lval2, r->dval1, result);
#endif
                                (sp++)->ivalue = result;
                            }
                            r->pc++;

                            break;
                        }


                        case op_dcmpg: {
                            --sp;
                            r->dval1 = (--sp)->dvalue;
                            --sp;
                            r->dval2 = (--sp)->dvalue;
                            if ((sp + 0)->ulvalue == 0x7ff8000000000000L || (sp + 2)->ulvalue == 0x7ff8000000000000L) {
                                (sp++)->ivalue = 1;
                            } else {
                                s32 result = r->dval2 == r->dval1 ? 0 : (r->dval2 > r->dval1 ? 1 : -1);

#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("dcmpg: %lf > %lf = %d\n", r->lval2, r->dval1, result);
#endif
                                (sp++)->ivalue = result;
                            }
                            r->pc++;

                            break;
                        }


                        case op_ifeq: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 == 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifeq: %d != 0  then jump \n", r->ival1);
#endif


                            break;
                        }


                        case op_ifne: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 != 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifne: %d != 0  then jump\n", r->ival1);
#endif


                            break;
                        }


                        case op_iflt: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 < 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("iflt: %d < 0  then jump  \n", r->ival1);
#endif


                            break;
                        }


                        case op_ifge: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 >= 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifge: %d >= 0  then jump \n", r->ival1);
#endif


                            break;
                        }


                        case op_ifgt: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 > 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifgt: %d > 0  then jump \n", r->ival1);
#endif


                            break;
                        }


                        case op_ifle: {
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 <= 0) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifle: %d <= 0  then jump \n", r->ival1);
#endif


                            break;
                        }


                        case op_if_icmpeq: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 == r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmpeq: %lld == %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_icmpne: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 != r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmpne: %lld != %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_icmplt: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 < r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmplt: %lld < %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_icmpge: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 >= r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmpge: %lld >= %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_icmpgt: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 > r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmpgt: %lld > %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_icmple: {
                            r->ival2 = (--sp)->ivalue;
                            r->ival1 = (--sp)->ivalue;
                            if (r->ival1 <= r->ival2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_icmple: %lld <= %lld \n", (s64) (intptr_t) r->ival1, (s64) (intptr_t) r->ival2);
#endif

                            break;
                        }


                        case op_if_acmpeq: {
                            r->rval2 = (--sp)->rvalue;
                            r->rval1 = (--sp)->rvalue;
                            if (r->rval1 == r->rval2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_acmpeq: %lld == %lld \n", (s64) (intptr_t) r->rval1, (s64) (intptr_t) r->rval2);
#endif

                            break;
                        }


                        case op_if_acmpne: {
                            r->rval2 = (--sp)->rvalue;
                            r->rval1 = (--sp)->rvalue;
                            if (r->rval1 != r->rval2) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_acmpne: %lld != %lld \n", (s64) (intptr_t) r->rval1, (s64) (intptr_t) r->rval2);
#endif

                            break;
                        }


                        case op_goto: {
                            r->offset = *((s16 *) (r->pc + 1));
                            r->pc += r->offset;
                            check_gc_pause(r->offset);

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("goto: %d\n", r->offset);
#endif
                            break;
                        }


                        case op_jsr: {
                            r->offset = *((s16 *) (r->pc + 1));
                            (sp++)->rvalue = (r->pc + 3);
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("jsr: %d\n", r->offset);
#endif
                            r->pc += r->offset;
                            break;
                        }


                        case op_ret: {
                            __returnaddress addr = (__refer) (intptr_t) localvar[(u8) r->pc[1]].rvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ret: %x\n", (s64) (intptr_t) addr);
#endif
                            r->pc = (u8 *) addr;
                            break;
                        }


                        case op_tableswitch: {
                            r->idx = (s32) (4 - ((((u64) (intptr_t) r->pc) - (u64) (intptr_t) (ca->code)) % 4)); //4 byte对齐

                            s32 default_offset = *((s32 *) (r->pc + r->idx));
                            r->idx += 4;
                            s32 low = *((s32 *) (r->pc + r->idx));
                            r->idx += 4;
                            s32 high = *((s32 *) (r->pc + r->idx));
                            r->idx += 4;

                            r->ival1 = (--sp)->ivalue; // pop an int from the stack
                            r->offset = 0;
                            if (r->ival1 < low || r->ival1 > high) {
                                // if its less than <low> or greater than <high>,
                                r->offset = default_offset; // branch to default
                            } else {
                                // otherwise
                                r->idx += (r->ival1 - low) * 4;

                                r->offset = *((s32 *) (r->pc + r->idx)); // branch to r->entry in table
                            }

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("tableswitch: val=%d, r->offset=%d\n", r->ival1, r->offset);
#endif
                            r->pc += r->offset;


                            break;
                        }


                        case op_lookupswitch: {
                            r->idx = (s32) (4 - ((((u64) (intptr_t) r->pc) - (u64) (intptr_t) (ca->code)) % 4)); //4 byte对齐

                            s32 default_offset = *((s32 *) (r->pc + r->idx));
                            r->idx += 4;
                            s32 n = *((s32 *) (r->pc + r->idx));
                            r->idx += 4;
                            s32 i, key;

                            r->ival1 = (--sp)->ivalue; // pop an int from the stack
                            r->offset = default_offset;
                            for (i = 0; i < n; i++) {
                                key = *((s32 *) (r->pc + r->idx));
                                r->idx += 4;
                                if (key == r->ival1) {
                                    r->offset = *((s32 *) (r->pc + r->idx));
                                    break;
                                } else {
                                    r->idx += 4;
                                }
                            }

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("tableswitch: val=%d, r->offset=%d\n", r->ival1, r->offset);
#endif
                            r->pc += r->offset;

                            break;
                        }


                        case op_lreturn:
                        case op_dreturn: {
#if _JVM_DEBUG_LOG_LEVEL > 5

                            peek_entry(stack->sp - 1, &r->entry);
                            invoke_deepth(r);
                            jvm_printf("ld_return=%lld/[%llx]\n", entry_2_long(&r->entry), entry_2_long(&r->entry));
#endif
                            --sp;
                            r->lval1 = (--sp)->lvalue;
                            stack->sp = sp;
                            localvar_dispose(r);
                            push_long(stack, r->lval1);
                            goto label_exit_while;
                            break;
                        }


                        case op_ireturn:
                        case op_freturn: {
                            r->ival1 = (--sp)->ivalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("if_return=%d/%f\n", r->ival1, *(f32 *) &r->ival1);
#endif
                            stack->sp = sp;
                            localvar_dispose(r);
                            push_int(stack, r->ival1);
                            goto label_exit_while;
                            break;
                        }
                        case op_areturn: {
                            r->rval1 = (--sp)->rvalue;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("a_return=[%llx]\n", (s64) (intptr_t) r->rval1);
#endif
                            stack->sp = sp;
                            localvar_dispose(r);
                            push_ref(stack, r->rval1);
                            goto label_exit_while;
                            break;
                        }


                        case op_return: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("return: \n");
#endif
                            stack->sp = sp;
                            localvar_dispose(r);
                            goto label_exit_while;
                            break;
                        }


                        case op_getstatic: {
                            stack->sp = sp;
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            if (!r->fi) {
                                r->cfr = class_get_constant_fieldref(clazz, r->idx);
                                stack->sp = sp;
                                r->fi = find_fieldInfo_by_fieldref(clazz, r->cfr->item.index, r);
                                sp = stack->sp;
                                r->cfr->fieldInfo = r->fi;
                                if (!r->fi) {
                                    r->err_msg = utf8_cstr(r->cfr->name);
                                    goto label_nosuchfield_throw;
                                }
                            }
                            if (r->fi->_this_class->status < CLASS_STATUS_CLINITED) {
                                stack->sp = sp;
                                class_clinit(r->fi->_this_class, r);
                                sp = stack->sp;
                            }
                            if (r->fi->isrefer) {
                                *r->pc = op_getstatic_ref;
                            } else {
                                // check variable type to determine s64/s32/f64/f32
                                switch (r->fi->datatype_bytes) {
                                    case 4: {
                                        *r->pc = op_getstatic_int;
                                        break;
                                    }
                                    case 1: {
                                        *r->pc = op_getstatic_byte;
                                        break;
                                    }
                                    case 8: {
                                        *r->pc = op_getstatic_long;
                                        break;
                                    }
                                    case 2: {
                                        if (r->fi->datatype_idx == DATATYPE_JCHAR) {
                                            *r->pc = op_getstatic_jchar;
                                        } else {
                                            *r->pc = op_getstatic_short;
                                        }
                                        break;
                                    }
                                    default: {
                                        break;
                                    }
                                }
                            }
                            break;
                        }


                        case op_putstatic: {
                            r->idx = *((u16 *) (r->pc + 1));

                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            if (!r->fi) {
                                r->cfr = class_get_constant_fieldref(clazz, r->idx);
                                stack->sp = sp;
                                r->fi = find_fieldInfo_by_fieldref(clazz, r->cfr->item.index, r);
                                sp = stack->sp;

                                r->cfr->fieldInfo = r->fi;
                                if (!r->fi) {
                                    r->err_msg = utf8_cstr(r->cfr->name);
                                    goto label_nosuchfield_throw;
                                }
                            }
                            if (r->fi->_this_class->status < CLASS_STATUS_CLINITED) {
                                stack->sp = sp;
                                class_clinit(r->fi->_this_class, r);
                                sp = stack->sp;
                            }
                            if (r->fi->isrefer) {
                                // garbage collection mark
                                *r->pc = op_putstatic_ref;
                            } else {
                                // check variable type to determain long/s32/f64/f32
                                // non-reference type
                                switch (r->fi->datatype_bytes) {
                                    case 4: {
                                        *r->pc = op_putstatic_int;
                                        break;
                                    }
                                    case 1: {
                                        *r->pc = op_putstatic_byte;
                                        break;
                                    }
                                    case 8: {
                                        *r->pc = op_putstatic_long;
                                        break;
                                    }
                                    case 2: {
                                        *r->pc = op_putstatic_short;
                                        break;
                                    }
                                    default: {
                                        break;
                                    }
                                }
                            }
                            break;
                        }


                        case op_getfield: {
                            s8 byte_changed = 0;
                            spin_lock(&r->jvm->lock_cloader);
                            {
                                if (*(r->pc) == op_getfield) {
                                    r->idx = *((u16 *) (r->pc + 1));
                                } else {
                                    byte_changed = 1;
                                }
                            }
                            spin_unlock(&r->jvm->lock_cloader);

                            if (!byte_changed) {
                                r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                                if (!r->fi) {
                                    r->cfr = class_get_constant_fieldref(clazz, r->idx);
                                    stack->sp = sp;
                                    r->fi = find_fieldInfo_by_fieldref(clazz, r->cfr->item.index, r);
                                    sp = stack->sp;
                                    r->cfr->fieldInfo = r->fi;
                                    if (!r->fi) {
                                        r->err_msg = utf8_cstr(r->cfr->name);
                                        goto label_nosuchfield_throw;
                                    }
                                }
                                if (r->fi->_this_class->status < CLASS_STATUS_CLINITED) {
                                    stack->sp = sp;
                                    class_clinit(r->fi->_this_class, r);
                                    sp = stack->sp;
                                }
                                spin_lock(&r->jvm->lock_cloader);
                                {
                                    if (r->fi->isrefer) {
                                        *r->pc = op_getfield_ref;
                                    } else {
                                        // check variable type to determine s64/s32/f64/f32
                                        switch (r->fi->datatype_bytes) {
                                            case 4: {
                                                *r->pc = op_getfield_int;
                                                break;
                                            }
                                            case 1: {
                                                *r->pc = op_getfield_byte;
                                                break;
                                            }
                                            case 8: {
                                                *r->pc = op_getfield_long;
                                                break;
                                            }
                                            case 2: {
                                                if (r->fi->datatype_idx == DATATYPE_JCHAR) {
                                                    *r->pc = op_getfield_jchar;
                                                } else {
                                                    *r->pc = op_getfield_short;
                                                }
                                                break;
                                            }
                                            default: {
                                                break;
                                            }
                                        }
                                    }
                                    *((u16 *) (r->pc + 1)) = r->fi->offset_instance;
                                }
                                spin_unlock(&r->jvm->lock_cloader);
                            } else {
                                //jvm_printf("getfield byte code changed by r->other thread.\n");
                            }
                            break;
                        }


                        case op_putfield: {
                            //there were a multithread error , one enter the r->ins but changed by another
                            s8 byte_changed = 0;

                            spin_lock(&r->jvm->lock_cloader);
                            {
                                if (*(r->pc) == op_putfield) {
                                    r->idx = *((u16 *) (r->pc + 1));
                                } else {
                                    byte_changed = 1;
                                }
                            }
                            spin_unlock(&r->jvm->lock_cloader);

                            if (!byte_changed) {
                                r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                                if (!r->fi) {
                                    r->cfr = class_get_constant_fieldref(clazz, r->idx);

                                    stack->sp = sp;
                                    r->fi = find_fieldInfo_by_fieldref(clazz, r->cfr->item.index, r);
                                    sp = stack->sp;
                                    r->cfr->fieldInfo = r->fi;
                                    if (!r->fi) {
                                        r->err_msg = utf8_cstr(r->cfr->name);
                                        goto label_nosuchfield_throw;
                                    }
                                }
                                if (r->fi->_this_class->status < CLASS_STATUS_CLINITED) {
                                    stack->sp = sp;
                                    class_clinit(r->fi->_this_class, r);
                                    sp = stack->sp;
                                }
                                spin_lock(&r->jvm->lock_cloader);
                                {
                                    if (r->fi->isrefer) {
                                        // garbage collection flag
                                        *r->pc = op_putfield_ref;
                                    } else {
                                        // non-reference type
                                        switch (r->fi->datatype_bytes) {
                                            case 4: {
                                                *r->pc = op_putfield_int;
                                                break;
                                            }
                                            case 1: {
                                                *r->pc = op_putfield_byte;
                                                break;
                                            }
                                            case 8: {
                                                *r->pc = op_putfield_long;
                                                break;
                                            }
                                            case 2: {
                                                *r->pc = op_putfield_short;
                                                break;
                                            }
                                            default: {
                                                break;
                                            }
                                        }
                                    }
                                    *((u16 *) (r->pc + 1)) = r->fi->offset_instance;
                                }
                                spin_unlock(&r->jvm->lock_cloader);
                            } else {
                                //jvm_printf("putfield byte code changed by r->other thread.\n");
                            }
                            break;
                        }


                        case op_invokevirtual: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));

                            r->ins = (sp - 1 - r->cmr->para_slots)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                MethodInfo *m = NULL;
                                /* inline vtable dispatch: no inline cache, the
                                 * vtable slot fetch is 3 loads + 2 compares.
                                 * DISP_ITABLE (class ref resolved to a default
                                 * method) falls through to select_dispatch_target */
                                {
                                    s32 kind = dispatch_kind_load(r->cmr);
                                    if (kind == DISP_UNRESOLVED) {
                                        /* first execution: resolve (may load) */
                                        spin_lock(&r->jvm->lock_cloader);
                                        {
                                            s32 derr = resolve_dispatch_plan(r, r->cmr, op_invokevirtual);
                                            if (derr) {
                                                spin_unlock(&r->jvm->lock_cloader);
                                                stack->sp = sp;
                                                push_ref(stack, exception_create_dispatch(derr, r));
                                                goto label_exception_handle;
                                            }
                                        }
                                        spin_unlock(&r->jvm->lock_cloader);
                                        kind = dispatch_kind_load(r->cmr);
                                    }
                                    if (kind == DISP_VTABLE) {
                                        JClass *rc = r->ins->mb.clazz;
                                        if (!rc->vtable || r->cmr->disp_slot >= rc->vtable_length) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE, r));
                                            goto label_exception_handle;
                                        }
                                        m = rc->vtable[r->cmr->disp_slot];
                                        if (!m || (!m->converted_code && !m->is_native)) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(JVM_EXCEPTION_ABSTRACTMETHOD, r));
                                            goto label_exception_handle;
                                        }
                                    } else {
                                        /* ITABLE or LINK_ERROR: delegate */
                                        s32 derr = select_dispatch_target_resolved(
                                            r->cmr, r->ins, op_invokevirtual, kind, &m);
                                        if (derr) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(derr, r));
                                            goto label_exception_handle;
                                        }
                                    }
                                }
                                r->m = m;
                                {
                                    s8 match = 0;
                                    if (r->m->is_getter) {
                                        //optimize getter eg:  int getSize(){return size;}
                                        r->ptr = (c8 *) r->m->converted_code->bytecode_for_jit; //must use original bytecode
                                        match = 1;
                                        //do getter here
                                        r->idx = *((u16 *) (r->ptr + 2)); //field desc index
                                        r->other = r->m->_this_class;
                                        stack->sp = sp;
                                        ret = _optimize_inline_getter(r->other, r->idx, r);
                                        sp = stack->sp;
                                        if (ret) {
                                            goto label_exception_handle;
                                        }
                                        //jvm_printf("methodcall getter %s.%s  %d  in    %s.%s\n", utf8_cstr(r->m->_this_class->name), utf8_cstr(r->m->name), r->m->_this_class->status, utf8_cstr(clazz->name), utf8_cstr(method->name));
                                        r->pc += 3;
                                    } else if (r->m->is_setter) {
                                        //optimize setter eg: void setSize(int size){this.size=size;}
                                        r->ptr = (c8 *) r->m->converted_code->bytecode_for_jit; //must use original bytecode
                                        match = 1;
                                        //do setter here
                                        r->idx = *((u16 *) (r->ptr + 3)); //field desc index
                                        r->other = r->m->_this_class;
                                        stack->sp = sp;
                                        ret = _optimize_inline_setter(r->other, r->idx, r);
                                        sp = stack->sp;
                                        if (ret) {
                                            goto label_exception_handle;
                                        }
                                        //jvm_printf("methodcall setter %s.%s  %d  in    %s.%s\n", utf8_cstr(r->m->_this_class->name), utf8_cstr(r->m->name), r->m->_this_class->status, utf8_cstr(clazz->name), utf8_cstr(method->name));
                                        r->pc += 3;
                                    }
                                    if (!match) {
                                        *r->pc = op_invokevirtual_fast;
                                    }
                                }
                            }

                            break;
                        }
                        case op_invokespecial: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->m = r->cmr->methodInfo;

                            if (!r->m) {
                                r->err_msg = utf8_cstr(r->cmr->name);
                                goto label_nosuchmethod_throw;
                            } else {
                                *r->pc = op_invokespecial_fast;
                                _optimize_empty_method_call(r->m, ca, r->pc); //if method is empty ,bytecode would replaced 'nop' and 'pop' para
                            }
                            break;
                        }


                        case op_invokestatic: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->m = r->cmr->methodInfo;

                            if (!r->m) {
                                r->err_msg = utf8_cstr(r->cmr->name);
                                goto label_nosuchmethod_throw;
                            } else {
                                *r->pc = op_invokestatic_fast;
                                _optimize_empty_method_call(r->m, ca, r->pc);
                            }
                            break;
                        }


                        case op_invokeinterface: {
                            //s32 paraCount = (u8) r->pc[3];
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->ins = (sp - 1 - r->cmr->para_slots)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                MethodInfo *m = NULL;
                                s32 kind = dispatch_kind_load(r->cmr);
                                s32 derr = kind == DISP_UNRESOLVED
                                               ? select_dispatch_target(r, r->cmr, r->ins,
                                                                        op_invokeinterface, &m)
                                               : select_dispatch_target_resolved(
                                                   r->cmr, r->ins, op_invokeinterface, kind, &m);
                                if (derr) {
                                    stack->sp = sp;
                                    push_ref(stack, exception_create_dispatch(derr, r));
                                    goto label_exception_handle;
                                }
                                r->m = m;
                                *r->pc = op_invokeinterface_fast;
                            }
                            break;
                        }


                        case op_invokedynamic: {
                            //get r->bootMethod struct
                            r->cid = class_get_invoke_dynamic(clazz, *((u16 *) (r->pc + 1)));
                            r->bootMethod = &clazz->bootstrapMethodAttr->bootstrap_methods[r->cid->bootstrap_method_attr_index]; //Boot

                            if (r->bootMethod->make == NULL) {
                                stack->sp = sp;
                                ret = invokedynamic_prepare(r, r->bootMethod, r->cid);
                                sp = stack->sp;
                                if (ret) {
                                    goto label_exception_handle;
                                }
                            }
                            r->m = r->bootMethod->make;

                            if (!r->m) {
                                r->err_msg = "Lambda generated method err";
                                goto label_nosuchmethod_throw;
                            } else {
                                *r->pc = op_invokedynamic_fast;
                            }
                            break;
                        }


                        case op_new: {
                            r->idx = *((u16 *) (r->pc + 1));

                            stack->sp = sp;
                            r->other = getClassByConstantClassRef(clazz, r->idx, r);
                            r->ins = NULL;
                            if (r->other) {
                                r->ins = instance_create(r, r->other);
                            }
                            sp = stack->sp;

                            if (!r->ins) {
                                goto label_outofmemory_throw;
                            }

                            (sp++)->rvalue = r->ins;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("new %s [%llx]\n", utf8_cstr(r->other->name), (s64) (intptr_t) r->ins);
#endif
                            r->pc += 3;
                            break;
                        }


                        case op_newarray: {
                            r->idx = r->pc[1];

                            r->count = (--sp)->ivalue;

                            if (r->count < 0) {
                                goto label_negativearraysize_throw;
                            }

                            stack->sp = sp;
                            r->ins = jarray_create_by_type_index(r, r->count, r->idx);
                            sp = stack->sp;
                            if (!r->ins) {
                                goto label_outofmemory_throw;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("(a)newarray  [%llx] type:%c , r->count:%d  \n", (s64) (intptr_t) r->ins, getDataTypeTag(r->idx), r->count);
#endif
                            (sp++)->rvalue = r->ins;
                            r->pc += 2;
                            break;
                        }


                        case op_anewarray: {
                            r->idx = *((u16 *) (r->pc + 1));

                            r->count = (--sp)->ivalue;
                            if (r->count < 0) {
                                goto label_negativearraysize_throw;
                            }
                            r->other = pairlist_get(clazz->arr_class_type, (__refer) (intptr_t) r->idx);

                            stack->sp = sp;
                            if (!r->other) {
                                //cache to speed
                                r->other = array_class_get_by_name(r, r->clazz->jloader, class_get_utf8_string(clazz, r->idx));
                                spin_lock(&r->jvm->lock_cloader);
                                {
                                    pairlist_put(clazz->arr_class_type, (__refer) (intptr_t) r->idx, r->other);
                                }
                                spin_unlock(&r->jvm->lock_cloader);
                            }
                            r->ins = jarray_create_by_class(r, r->count, r->other);
                            sp = stack->sp;

                            if (!r->ins) {
                                goto label_outofmemory_throw;
                            }

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("(a)newarray  [%llx] type:%d , r->count:%d  \n", (s64) (intptr_t) r->ins, r->other->arr_class_type, r->count);
#endif
                            (sp++)->rvalue = r->ins;
                            r->pc += 3;
                            break;
                        }


                        case op_arraylength: {
                            r->ins = (--sp)->rvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("arraylength  [%llx].arr_body[%llx] len:%d  \n", (s64) (intptr_t) r->ins, (s64) (intptr_t) jarray_body(r->ins), jarray_length(r->ins));
#endif
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                (sp++)->ivalue = jarray_length(r->ins);
                                r->pc++;
                            }
                            break;
                        }


                        case op_athrow: {
#if _JVM_DEBUG_LOG_LEVEL > 5
                            r->ins = (Instance *) pop_ref(stack);
                            push_ref(stack, (__refer) r->ins);
                            invoke_deepth(r);
                            jvm_printf("athrow  [%llx].exception throws  \n", (s64) (intptr_t) r->ins);
#endif
                            stack->sp = sp;
                            goto label_exception_handle;
                            break;
                        }


                        case op_checkcast: {
                            r->idx = *((u16 *) (r->pc + 1));

                            r->ins = (--sp)->rvalue;

                            stack->sp = sp;
                            if (!checkcast(r, r->ins, r->idx)) {
                                goto label_checkcast_throw;
                            } else {
                                sp = stack->sp;
                                (sp++)->rvalue = r->ins;
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("checkcast  %s instancof %s  \n", utf8_cstr(r->ins->mb.clazz->name), utf8_cstr(class_get_constant_classref(clazz, r->idx)->name));
#endif

                            break;
                        }


                        case op_instanceof: {
                            r->ins = (--sp)->rvalue;
                            r->idx = *((u16 *) (r->pc + 1));

                            s8 checkok = 0;
                            if (!r->ins) {
                            } else if (r->ins->mb.type & (MEM_TYPE_INS | MEM_TYPE_ARR)) {
                                stack->sp = sp;
                                if (instance_of(r->ins, getClassByConstantClassRef(clazz, r->idx, r))) {
                                    checkok = 1;
                                }
                                sp = stack->sp;
                            }
                            (sp++)->ivalue = checkok;

#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("instanceof  [%llx] instancof %s  \n", (s64) (intptr_t) r->ins, utf8_cstr(class_get_constant_classref(clazz, r->idx)->name));
#endif
                            r->pc += 3;
                            break;
                        }


                        case op_monitorenter: {
                            r->ins = (--sp)->rvalue;
                            stack->sp = sp;
                            if (!r->ins)goto label_null_throw;
                            //jdwp invoke: all java threads are frozen, the jdwp
                            //dispatcher is the only executor - locking is
                            //skipped (a real lock could be owned by a frozen
                            //thread and deadlock the dispatcher)
                            if (!jdwp_is_ignore_sync(r->jvm->jdwpserver, r)) {
                                if (jthread_lock(&r->ins->mb, r) != RUNTIME_STATUS_NORMAL) {
                                    ret = RUNTIME_STATUS_ERROR;
                                    goto label_exit_while;
                                }
                            }
                            sp = stack->sp;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("monitorenter  [%llx] %s  \n", (s64) (intptr_t) r->ins, r->ins ? utf8_cstr(r->ins->mb.clazz->name) : "null");
#endif
                            r->pc++;
                            break;
                        }


                        case op_monitorexit: {
                            r->ins = (--sp)->rvalue;
                            stack->sp = sp;
                            if (!r->ins)goto label_null_throw;
                            //symmetric with op_monitorenter: never unlock a
                            //monitor that was acquired with locking skipped
                            if (!jdwp_is_ignore_sync(r->jvm->jdwpserver, r)) {
                                int ret = jthread_unlock(&r->ins->mb, r);
                                if (ret < 0) {
                                    s32 debug = 1;
                                }
                            }
                            sp = stack->sp;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("monitorexit  [%llx] %s  \n", (s64) (intptr_t) r->ins, r->ins ? utf8_cstr(r->ins->mb.clazz->name) : "null");
#endif
                            r->pc++;
                            break;
                        }


                        case op_wide: {
#if _JVM_DEBUG_LOG_LEVEL > 5

                            invoke_deepth(r);
                            jvm_printf("wide  \n");
#endif
                            r->pc++;
                            switch (*r->pc) {
                                case op_iload:
                                case op_fload: {
                                    (sp++)->ivalue = localvar[*((u16 *) (r->pc + 1))].ivalue;
                                    r->pc += 3;
                                    break;
                                }
                                case op_aload: {
                                    (sp++)->rvalue = localvar[*((u16 *) (r->pc + 1))].rvalue;
                                    r->pc += 3;
                                    break;
                                }
                                case op_lload:
                                case op_dload: {
                                    (sp++)->lvalue = localvar[*((u16 *) (r->pc + 1))].lvalue;
                                    sp++;
                                    r->pc += 3;
                                    break;
                                }
                                case op_istore:
                                case op_fstore: {
                                    localvar[*((u16 *) (r->pc + 1))].ivalue = (--sp)->ivalue;
                                    r->pc += 3;
                                    break;
                                }
                                case op_astore: {
                                    localvar[*((u16 *) (r->pc + 1))].rvalue = (--sp)->rvalue;
                                    r->pc += 3;
                                    break;
                                }
                                case op_lstore:
                                case op_dstore: {
                                    --sp;
                                    localvar[*((u16 *) (r->pc + 1))].lvalue = (--sp)->lvalue;
                                    r->pc += 3;
                                    break;
                                }
                                case op_ret: {
                                    __refer addr = (__refer) (intptr_t) localvar[*((u16 *) (r->pc + 1))].lvalue;

#if _JVM_DEBUG_LOG_LEVEL > 5
                                    invoke_deepth(r);
                                    jvm_printf("wide ret: %x\n", (s64) (intptr_t) addr);
#endif
                                    r->pc = (u8 *) addr;
                                    break;
                                }
                                case op_iinc: {
                                    localvar[*((u16 *) (r->pc + 1))].ivalue += *((s16 *) (r->pc + 3));
#if _JVM_DEBUG_LOG_LEVEL > 5
                                    invoke_deepth(r);
                                    jvm_printf("wide iinc: localvar(%d) = %d , inc %d\n", *((u16 *) (r->pc + 1)), r->localvar[*((u16 *) (r->pc + 1))].ivalue, *((u16 *) (r->pc + 3)));
#endif
                                    r->pc += 5;
                                    break;
                                }
                                default:
                                    _op_notsupport(r->pc, r);
                            }
                            break;
                        }


                        case op_multianewarray: {
                            //data type index

                            r->ustr = class_get_utf8_string(clazz, *((u16 *) (r->pc + 1)));
                            //array dim
                            r->count = (u8) r->pc[3];
#ifdef __JVM_OS_VS__
                            s32 dim[32];
#else
                            s32 dim[r->count];
#endif
                            s32 has_negative_dimension = 0;
                            for (r->idx = 0; r->idx < r->count; r->idx++) {
                                dim[r->idx] = (--sp)->ivalue;
                                if (dim[r->idx] < 0) has_negative_dimension = 1;
                            }

                            if (has_negative_dimension) {
                                goto label_negativearraysize_throw;
                            }

                            stack->sp = sp;
                            r->ins = jarray_multi_create(r, dim, r->count, r->ustr, 0);
                            sp = stack->sp;
                            if (!r->ins) {
                                goto label_outofmemory_throw;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("multianewarray  [%llx] type:%s , r->count:%d  \n", (s64) (intptr_t) r->ins, utf8_cstr(r->ustr), r->count);
#endif
                            (sp++)->rvalue = r->ins;
                            r->pc += 4;
                            break;
                        }


                        case op_ifnull: {
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifnonnull: %d/%llx != 0  then jump %d \n", (s32) (intptr_t) r->ins, (s64) (intptr_t) r->ins);
#endif


                            break;
                        }


                        case op_ifnonnull: {
                            r->ins = (--sp)->rvalue;
                            if (r->ins) {
                                r->offset = *((s16 *) (r->pc + 1));
                                r->pc += r->offset;
                                check_gc_pause(r->offset);
                            } else {
                                r->pc += 3;
                            }
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("ifnonnull: %d/%llx != 0  then \n", (s32) (intptr_t) r->ins, (s64) (intptr_t) r->ins);
#endif
                            break;
                        }


                        case op_goto_w: {
                            r->offset = *((s32 *) (r->pc + 1));
                            r->pc += r->offset;
                            check_gc_pause(r->offset);
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("goto: %d\n", r->offset);
#endif
                            break;
                        }


                        case op_jsr_w: {
                            r->offset = *((s32 *) (r->pc + 1));
                            (sp++)->rvalue = (r->pc + 5);
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("jsr_w: %d\n", r->offset);
#endif
                            r->pc += r->offset;
                            break;
                        }


                        case op_breakpoint: {
#if _JVM_DEBUG_LOG_LEVEL > 5

                            invoke_deepth(r);
                            jvm_printf("breakpoint \n");
#endif
                            break;
                        }


                        case op_getstatic_ref: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);

                            (sp++)->rvalue = *((__refer *) r->ptr);
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: ref  %d = %s.%s \n", "getstatic", (s64) (intptr_t) getFieldRefer(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_getstatic_long: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            (sp++)->lvalue = *((s64 *) r->ptr);
                            sp++;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: long  %d = %s.%s \n", "getstatic", getFieldLong(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_getstatic_int: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            (sp++)->ivalue = *((s32 *) r->ptr);
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: int  %d = %s.%s \n", "getstatic", (s32) getFieldInt(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_getstatic_short: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            (sp++)->ivalue = *((s16 *) r->ptr);
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: short  %d = %s.%s \n", "getstatic", (s32) getFieldShort(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_getstatic_jchar: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            (sp++)->ivalue = *((u16 *) r->ptr);
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: char  %d = %s.%s \n", "getstatic", (s32) (u16) getFieldChar(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_getstatic_byte: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            (sp++)->ivalue = *((s8 *) r->ptr);
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: byte  %d = %s.%s \n", "getstatic", (s32) getFieldByte(r->ptr), utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }


                        case op_putstatic_ref: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            *((__refer *) r->ptr) = (--sp)->rvalue;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: ref  %s.%s = %llx \n", "putstatic", utf8_cstr(clazz->name), utf8_cstr(r->fi->name), (s64) (intptr_t) getFieldRefer(r->ptr));
#endif
                            break;
                        }


                        case op_putstatic_long: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            --sp;
                            *((s64 *) r->ptr) = (--sp)->lvalue;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: long  %s.%s = %lld \n", "putstatic", utf8_cstr(clazz->name), utf8_cstr(r->fi->name), getFieldLong(r->ptr));
#endif
                            break;
                        }

                        case op_putstatic_int: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            *((s32 *) r->ptr) = (--sp)->ivalue;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: int  %s.%s = %d \n", "putstatic", utf8_cstr(clazz->name), utf8_cstr(r->fi->name), (s32) getFieldInt(r->ptr));
#endif
                            break;
                        }

                        case op_putstatic_short: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            *((s16 *) r->ptr) = (s16) (--sp)->ivalue;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: short  %s.%s = %d \n", "putstatic", utf8_cstr(clazz->name), utf8_cstr(r->fi->name), (s32) getFieldShort(r->ptr));
#endif
                            break;
                        }

                        case op_putstatic_byte: {
                            r->idx = *((u16 *) (r->pc + 1));
                            r->fi = class_get_constant_fieldref(clazz, r->idx)->fieldInfo;
                            r->ptr = getStaticFieldPtr(r->fi);
                            *((s8 *) r->ptr) = (s8) (--sp)->ivalue;
                            r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                            invoke_deepth(r);
                            jvm_printf("%s: byte  %s.%s = %d \n", "putstatic", utf8_cstr(clazz->name), utf8_cstr(r->fi->name), (s32) getFieldByte(r->ptr));
#endif
                            break;
                        }


                        case op_getfield_ref: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->rvalue = *((__refer *) r->ptr);
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: ref %llx = %s. \n", "getfield", getFieldRefer(r->ptr), utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_getfield_long: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->lvalue = *((s64 *) r->ptr);
                                sp++;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: long %lld = %s. \n", "getfield", getFieldLong(r->ptr), utf8_cstr(r->ins->mb.clazz->name));
#endif
                            }
                            break;
                        }


                        case op_getfield_int: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->ivalue = *((s32 *) r->ptr);
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: int %d = %s  \n", "getfield", (s32) getFieldInt(r->ptr), utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_getfield_short: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->ivalue = *((s16 *) r->ptr);
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: short %d = %s \n", "getfield", (s32) getFieldShort(r->ptr), utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_getfield_jchar: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->ivalue = *((u16 *) r->ptr);
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: char %d = %s \n", "getfield", (s32) (u16) getFieldChar(r->ptr), utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_getfield_byte: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);

                                (sp++)->ivalue = *((s8 *) r->ptr);
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: byte %d = %s \n", "getfield", (s32) getFieldByte(r->ptr), utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_putfield_ref: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->rval1 = (--sp)->rvalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                // check variable type to determain long/s32/f64/f32
                                r->ptr = &(instance_fields(r->ins)[r->offset]);
                                *((__refer *) r->ptr) = r->rval1;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: ref %s\n", "putfield", utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_putfield_long: {
                            r->offset = *((u16 *) (r->pc + 1));
                            --sp;
                            r->lval1 = (--sp)->lvalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);
                                *((s64 *) r->ptr) = r->lval1;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: long %s\n", "putfield", utf8_cstr(clazz->name));
#endif
                            }
                            break;
                        }


                        case op_putfield_int: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ival1 = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);
                                *((s32 *) r->ptr) = r->ival1;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: int %s.= %d\n", "putfield", utf8_cstr(clazz->name), r->ival1);
#endif
                            }
                            break;
                        }


                        case op_putfield_short: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ival1 = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);
                                *((s16 *) r->ptr) = (s16) r->ival1;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: short %s. = %d\n", "putfield", utf8_cstr(clazz->name), r->ival1);
#endif
                            }
                            break;
                        }


                        case op_putfield_byte: {
                            r->offset = *((u16 *) (r->pc + 1));
                            r->ival1 = (--sp)->ivalue;
                            r->ins = (--sp)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                r->ptr = &(instance_fields(r->ins)[r->offset]);
                                *((s8 *) r->ptr) = (s8) r->ival1;
                                r->pc += 3;
#if _JVM_DEBUG_LOG_LEVEL > 5
                                invoke_deepth(r);
                                jvm_printf("%s: byte %s. = %d\n", "putfield", utf8_cstr(clazz->name), r->ival1);
#endif
                            }
                            break;
                        }


                        case op_invokevirtual_fast: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->ins = (sp - 1 - r->cmr->para_slots)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                MethodInfo *m = NULL;
                                /* inline vtable dispatch (same as cold path,
                                 * plan is expected published by now) */
                                {
                                    s32 kind = dispatch_kind_load(r->cmr);
                                    if (kind == DISP_VTABLE) {
                                        JClass *rc = r->ins->mb.clazz;
                                        if (!rc->vtable || r->cmr->disp_slot >= rc->vtable_length) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(JVM_EXCEPTION_INCOMPATIBLECLASSCHANGE, r));
                                            goto label_exception_handle;
                                        }
                                        m = rc->vtable[r->cmr->disp_slot];
                                        if (!m || (!m->converted_code && !m->is_native)) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(JVM_EXCEPTION_ABSTRACTMETHOD, r));
                                            goto label_exception_handle;
                                        }
                                    } else {
                                        /* ITABLE / UNRESOLVED / LINK_ERROR */
                                        s32 derr = select_dispatch_target_resolved(r->cmr, r->ins, op_invokevirtual, kind, &m);
                                        if (derr) {
                                            stack->sp = sp;
                                            push_ref(stack, exception_create_dispatch(derr, r));
                                            goto label_exception_handle;
                                        }
                                    }
                                }
#if _JVM_DEBUG_BYTECODE_PROFILE
                                spent = nanoTime() - start_at;
#endif
                                r->m = m;
                                stack->sp = sp;
                                ret = execute_method_impl(r->m, r);
                                sp = stack->sp;
                                if (ret) {
                                    goto label_exception_handle;
                                }
                                r->pc += 3;
                            }

                            break;
                        }


                        case op_invokespecial_fast: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->m = r->cmr->methodInfo;
#if _JVM_DEBUG_BYTECODE_PROFILE
                            spent = nanoTime() - start_at;
#endif
                            stack->sp = sp;
                            ret = execute_method_impl(r->m, r);
                            sp = stack->sp;
                            if (ret) {
                                goto label_exception_handle;
                            }
                            r->pc += 3;
                            break;
                        }


                        case op_invokestatic_fast: {
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));
                            r->m = r->cmr->methodInfo;
#if _JVM_DEBUG_BYTECODE_PROFILE
                            spent = nanoTime() - start_at;
#endif
                            stack->sp = sp;
                            ret = execute_method_impl(r->m, r);
                            sp = stack->sp;
                            if (ret) {
                                goto label_exception_handle;
                            }
                            r->pc += 3;
                            break;
                        }


                        case op_invokeinterface_fast: {
                            //此cmr所描述的方法，对于不同的实例，有不同的method
                            r->cmr = class_get_constant_method_ref(clazz, *((u16 *) (r->pc + 1)));

                            r->ins = (sp - 1 - r->cmr->para_slots)->rvalue;
                            if (!r->ins) {
                                goto label_null_throw;
                            } else {
                                MethodInfo *m = NULL;
                                s32 kind = dispatch_kind_load(r->cmr);
                                s32 derr = kind == DISP_UNRESOLVED
                                               ? select_dispatch_target(r, r->cmr, r->ins, op_invokeinterface, &m)
                                               : select_dispatch_target_resolved(r->cmr, r->ins, op_invokeinterface, kind, &m);
                                if (derr) {
                                    stack->sp = sp;
                                    push_ref(stack, exception_create_dispatch(derr, r));
                                    goto label_exception_handle;
                                }
#if _JVM_DEBUG_BYTECODE_PROFILE
                                spent = nanoTime() - start_at;
#endif
                                r->m = m;
                                stack->sp = sp;
                                ret = execute_method_impl(r->m, r);
                                sp = stack->sp;
                                if (ret) {
                                    goto label_exception_handle;
                                }
                                r->pc += 5;
                            }
                            break;
                        }


                        case op_invokedynamic_fast: {
                            //get r->bootMethod struct
                            r->cid = class_get_invoke_dynamic(clazz, *((u16 *) (r->pc + 1)));
                            r->bootMethod = &clazz->bootstrapMethodAttr->bootstrap_methods[r->cid->bootstrap_method_attr_index]; //Boot
                            r->m = r->bootMethod->make;

#if _JVM_DEBUG_BYTECODE_PROFILE
                            spent = nanoTime() - start_at;
#endif
                            // run make to generate instance of Lambda Class
                            stack->sp = sp;
                            ret = execute_method_impl(r->m, r);
                            sp = stack->sp;
                            if (ret) {
                                goto label_exception_handle;
                            }

                            r->pc += 5;
                            break;
                        }

                        default:
                            _op_notsupport(r->pc, r);
                    }

                    /* ================================== r->pc end =============================*/

#if _JVM_DEBUG_BYTECODE_PROFILE
                    //time
                    if (!spent) spent = nanoTime() - start_at;
                    profile_put(cur_inst, spent, 1);
#endif
                    continue;
                label_outofbounds_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_ARRAYINDEXOUTOFBOUNDS, r));
                        goto label_exception_handle;
                    }

                label_outofmemory_throw: {
                        stack->sp = sp;
                        exception_throw_out_of_memory(r);
                        goto label_exception_handle;
                    }

                label_null_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_NULLPOINTER, r));
                        goto label_exception_handle;
                    }

                label_nosuchmethod_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create_str(JVM_EXCEPTION_NOSUCHMETHOD, r, r->err_msg));
                        goto label_exception_handle;
                    }

                label_nosuchfield_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create_str(JVM_EXCEPTION_NOSUCHFIELD, r, r->err_msg));
                        goto label_exception_handle;
                    }

                label_arrithmetic_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_ARRITHMETIC, r));
                        goto label_exception_handle;
                    }

                label_checkcast_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_CLASSCAST, r));
                        goto label_exception_handle;
                    }

                label_negativearraysize_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_NEGATIVEARRAYSIZE, r));
                        goto label_exception_handle;
                    }

                label_arraystore_throw: {
                        stack->sp = sp;
                        push_ref(stack, (__refer) exception_create(JVM_EXCEPTION_ARRAYSTORE, r));
                        goto label_exception_handle;
                    }

                label_exception_handle:
                    if (ret == RUNTIME_STATUS_ERROR || ret == RUNTIME_STATUS_INTERRUPT) {
                        /* ERROR / INTERRUPT carry no exception reference on
                         * the stack and no catch block may observe them: exit
                         * this frame and propagate the status unchanged.  A
                         * JIT'd callee stopped at a safepoint returns
                         * INTERRUPT through execute_method_impl. */
                        goto label_exit_while;
                    }
                    // there is exception handle, but not error handle

                    ret = RUNTIME_STATUS_EXCEPTION;
                    if (exception_handle(r->stack, r)) {
                        ret = RUNTIME_STATUS_NORMAL;

                        runtime_clear_stacktrack(r);
                    } else {
                        arraylist_push_back(r->thrd_info->stacktrack, method);
                        arraylist_push_back(r->thrd_info->lineNo, (__refer) (intptr_t) getLineNumByIndex(ca, (s32) (r->pc - ca->code)));
                        break;
                    }
                    sp = stack->sp;
#if _JVM_DEBUG_BYTECODE_PROFILE
                    //time
                    if (!spent) spent = nanoTime() - start_at;
                    profile_put(cur_inst, spent, 1);
#endif
                    continue;

                label_osr_exit:
                    /* the compiled body ran this frame to completion through
                     * the OSR trampoline; same result contract as an entry
                     * compiled call */
                    if (ret != RUNTIME_STATUS_ERROR) {
                        ret = _finish_compiled_call(method, r, ret);
                    }
                    goto label_exit_while;

                label_exit_while:
#if _JVM_DEBUG_BYTECODE_PROFILE
                    //time
                    if (!spent) spent = nanoTime() - start_at;
                    profile_put(cur_inst, spent, 1);
#endif
                    break;
                } while (1); //end while
            }

            //sync end
            if (method->is_sync)_synchronized_unlock_method(method, r);
        } else {
            jvm_printf("method code attribute is null.");
        }
    } else {
        // native method: a resolved JNI function is the same callable
        // shape as a compiled java body, so it shares the call tail
        localvar_init(r, method->para_slots, method->para_slots);
        // cache native method calls
        if (!method->native_func) {
            // find and cache the native method
            java_native_method *native = find_native_method(r->jvm, utf8_cstr(clazz->name), utf8_cstr(method->name), utf8_cstr(method->descriptor));
            if (!native) {
                _nosuchmethod_check_exception(utf8_cstr(method->name), stack, r);
                ret = RUNTIME_STATUS_EXCEPTION;
            } else {
                method->native_func = native->func_pointer;
            }
        }

        if (r->thrd_info->is_stop) {
            //if stop=1 then exit thread
            ret = RUNTIME_STATUS_ERROR;
        } else if (method->native_func) {
            if (method->is_sync && _synchronized_lock_method(method, r) != RUNTIME_STATUS_NORMAL) {
                ret = RUNTIME_STATUS_ERROR;
            } else {
                ret = method->native_func(r, clazz);
                if (method->is_sync)_synchronized_unlock_method(method, r);
            }
            if (ret != RUNTIME_STATUS_ERROR) {
                ret = _finish_compiled_call(method, r, ret);
            }
        }
    }


#if _JVM_DEBUG_LOG_LEVEL > 3
    if (ret != RUNTIME_STATUS_EXCEPTION) {
        if (stack->sp != r->localvar + method->return_slots) {
            invoke_deepth(r);
            jvm_printf("Thread.stop = %d | Stack size  %s.%s%s in:%d out:%d  \n", r->thrd_info->is_stop, utf8_cstr(clazz->name), utf8_cstr(method->name), utf8_cstr(method->descriptor), (r->localvar - r->stack->store), stack_size(stack));
            if (!r->thrd_info->is_stop)exit(1); //if is_stop , the stack will confuse
        }
    }
#endif
#if _JVM_DEBUG_METHOD_PROFILE || _JVM_DEBUG_SLOW_CALL_PROFILE
    s64 spent = nanoTime() - start_time;
#if _JVM_DEBUG_SLOW_CALL_PROFILE
    s64 slow_spent = spent;
    if (r->jvm && r->jvm->collector) {
        s64 gc_pause_now = ATOMIC_ADD64(&r->jvm->collector->stw_total_ns, 0);
        s64 gc_pause_spent = gc_pause_now - r->slow_profile_gc_pause_at_enter;
        if (gc_pause_spent > 0) {
            slow_spent -= gc_pause_spent;
            if (slow_spent < 0) {
                slow_spent = 0;
            }
        }
    }
    if (r->parent) {
        r->parent->slow_profile_child_spent += slow_spent;
    }
    profile_slow_call_record(r, method, slow_spent);
#endif
#if _JVM_DEBUG_METHOD_PROFILE
    ATOMIC_ADD64(&method->profile_total_time, spent);
    ATOMIC_ADD64(&method->profile_count, 1);
    // update max time
    s64 max = method->profile_max_time;
    while (spent > max) {
        if (ATOMIC_CAS64(&method->profile_max_time, max, spent)) break;
        max = method->profile_max_time;
    }
    //profile_method_print(pruntime->jvm);
#endif
#endif
    //jdwp: stepping out of the outermost java frame (parent is the thread
    //root runtime, e.g. a native GLFW/JNI callback or main itself) never
    //reaches another interpreter instruction, so the pending step would be
    //lost and the debugger would wait forever. Complete it here instead.
    if (pruntime && pruntime->method == NULL
        && IS_JDWP_ENABLED(r) && jdwp_client_count(r->jvm->jdwpserver)) {
        jdwp_check_debug_step_on_return(r);
    }
    runtime_destroy_inl(r);
    pruntime->son = NULL; //must clear , required for getLastSon()

#if _JVM_DEBUG_LOG_LEVEL > 3
    invoke_deepth(pruntime);
    jvm_printf("} // %s.%s%s\n", utf8_cstr(method->_this_class->name),
               utf8_cstr(method->name), utf8_cstr(method->descriptor));
#endif
    return ret;
}
