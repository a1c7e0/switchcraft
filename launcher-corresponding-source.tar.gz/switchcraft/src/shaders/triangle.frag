#version 450
layout(location=0) out vec4 color;
void main() { color=vec4(0.15,0.85,0.3,1); }
